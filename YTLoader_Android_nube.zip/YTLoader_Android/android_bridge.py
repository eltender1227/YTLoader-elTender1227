# -*- coding: utf-8 -*-
"""
Todo lo específico de Android vive aquí (pyjnius). Fuera de Android cada función hace algo inofensivo,
así que el resto del programa se puede probar en un ordenador.
⚠ Estas funciones NO se han podido probar en un dispositivo real (ver README).
"""
from __future__ import annotations

import logging
import mimetypes
import os
import sys

log = logging.getLogger("ytloader.android")
IS_ANDROID = "ANDROID_ARGUMENT" in os.environ or hasattr(sys, "getandroidapilevel")


def _activity():
    from jnius import autoclass

    return autoclass("org.kivy.android.PythonActivity").mActivity


def default_download_dir() -> str:
    """Carpeta propia de la app (no necesita permisos). Android: .../Android/data/<paquete>/files/YTLoader."""
    if IS_ANDROID:
        try:
            return os.path.join(str(_activity().getExternalFilesDir(None).getAbsolutePath()), "YTLoader")
        except Exception:
            log.exception("No se pudo obtener getExternalFilesDir")
    return os.path.join(os.path.expanduser("~"), "YTLoader_downloads")


def request_permissions() -> None:
    """Android 13+: permiso para mostrar notificaciones (no hace falta ninguno para descargar a la carpeta propia)."""
    if not IS_ANDROID:
        return
    try:
        from android.permissions import request_permissions as request

        request(["android.permission.POST_NOTIFICATIONS"])
    except Exception:
        log.exception("No se pudieron pedir permisos")


def _text_from_intent(intent) -> str:
    try:
        if intent is None:
            return ""
        action = str(intent.getAction() or "")
        if action == "android.intent.action.SEND":
            return str(intent.getStringExtra("android.intent.extra.TEXT") or "")
        if action == "android.intent.action.VIEW":
            return str(intent.getDataString() or "")
    except Exception:
        log.exception("No se pudo leer el intent")
    return ""


def get_shared_text() -> str:
    """Texto enviado con «Compartir → YTLoader» al abrir la app."""
    if not IS_ANDROID:
        return ""
    try:
        return _text_from_intent(_activity().getIntent())
    except Exception:
        return ""


def bind_new_intent(callback) -> None:
    """callback(texto) cuando llega un «Compartir» con la app ya abierta."""
    if not IS_ANDROID:
        return
    try:
        from android import activity

        activity.bind(on_new_intent=lambda intent: callback(_text_from_intent(intent)))
    except Exception:
        log.exception("No se pudo enlazar on_new_intent")


def move_to_background() -> bool:
    """Envía la app al fondo (como pulsar Inicio). Sin servicio en primer plano Android puede cerrarla."""
    if not IS_ANDROID:
        return False
    try:
        return bool(_activity().moveTaskToBack(True))
    except Exception:
        return False


def publish_to_media_store(path: str, kind: str) -> bool:
    """
    Copia el archivo a Música/YTLoader o Películas/YTLoader (visible para reproductores y galería). Android 10+.
    El original se conserva en la carpeta de la app (así nunca se pierde nada si algo falla).
    """
    if not IS_ANDROID or not os.path.isfile(path):
        return False
    try:
        from jnius import autoclass

        sdk = autoclass("android.os.Build$VERSION").SDK_INT
        if sdk < 29:
            return False
        MediaStore = autoclass("android.provider.MediaStore")
        values = autoclass("android.content.ContentValues")()
        resolver = _activity().getContentResolver()
        mime = mimetypes.guess_type(path)[0] or ("audio/mp4" if kind == "music" else "video/mp4")
        if path.lower().endswith(".ts"):
            mime = "video/mp2t"
        music = kind == "music"
        collection = (MediaStore.Audio.Media if music else MediaStore.Video.Media).EXTERNAL_CONTENT_URI
        values.put("_display_name", os.path.basename(path))
        values.put("mime_type", mime)
        values.put("relative_path", "Music/YTLoader" if music else "Movies/YTLoader")
        values.put("is_pending", 1)
        uri = resolver.insert(collection, values)
        if uri is None:
            return False
        source = autoclass("java.io.FileInputStream")(path)
        target = resolver.openOutputStream(uri)
        autoclass("android.os.FileUtils").copy(source, target)
        source.close()
        target.close()
        values.clear()
        values.put("is_pending", 0)
        resolver.update(uri, values, None, None)
        return True
    except Exception:
        log.exception("No se pudo publicar %s en MediaStore", path)
        return False
