# -*- coding: utf-8 -*-
"""
Carátula incrustada SIN ffmpeg: mutagen (Python puro, compatible con python-for-android) escribe la portada
y las etiquetas en archivos .m4a. Todo es opcional: si falta mutagen/Pillow o falla la red, no pasa nada.
"""
from __future__ import annotations

import io
import logging
import urllib.request
from urllib.parse import urlsplit

log = logging.getLogger("ytloader.covers")
_YT_THUMBS = ("maxresdefault", "sddefault", "hqdefault")
_ALLOWED_HOSTS = {"i.ytimg.com", "img.youtube.com", "i1.sndcdn.com", "i.scdn.co"}


def candidate_urls(info: dict) -> list[str]:
    """JPEG conocidos (mutagen/MP4 no acepta WebP). En YouTube se construyen desde el id."""
    urls: list[str] = []
    if str(info.get("extractor_key", "")).lower().startswith("youtube") and info.get("id"):
        urls += [f"https://i.ytimg.com/vi/{info['id']}/{name}.jpg" for name in _YT_THUMBS]
    thumb = str(info.get("thumbnail") or "")
    if thumb.lower().split("?")[0].endswith((".jpg", ".jpeg")):
        urls.append(thumb)
    return [u for u in urls if urlsplit(u).scheme == "https" and (urlsplit(u).hostname or "") in _ALLOWED_HOSTS]


def _download(url: str, timeout: float = 15.0, limit: int = 3_000_000) -> bytes | None:
    try:
        request = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(request, timeout=timeout) as response:  # noqa: S310 (https + host permitido)
            data = response.read(limit + 1)
        return data if 1000 < len(data) <= limit else None
    except Exception:
        return None


def _square(data: bytes) -> bytes:
    """Recorte central cuadrado (ideal para reproductores). Sin Pillow se deja tal cual."""
    try:
        from PIL import Image

        image = Image.open(io.BytesIO(data)).convert("RGB")
        side = min(image.size)
        left, top = (image.width - side) // 2, (image.height - side) // 2
        out = io.BytesIO()
        image.crop((left, top, left + side, top + side)).save(out, "JPEG", quality=92)
        return out.getvalue()
    except Exception:
        return data


def embed_cover(path: str, info: dict, fetch=_download) -> bool:
    """Incrusta portada + título/artista en un .m4a. Devuelve True si quedó la carátula."""
    if not path.lower().endswith((".m4a", ".mp4")):
        return False
    try:
        from mutagen.mp4 import MP4, MP4Cover
    except ImportError:
        return False
    try:
        data = next((d for d in (fetch(u) for u in candidate_urls(info)) if d), None)
        tags = MP4(path)
        if tags.tags is None:
            tags.add_tags()
        if info.get("track") or info.get("title"):
            tags["\xa9nam"] = [str(info.get("track") or info.get("title"))]
        artist = info.get("artist") or info.get("uploader") or info.get("channel")
        if artist:
            tags["\xa9ART"] = [str(artist)]
        if info.get("album"):
            tags["\xa9alb"] = [str(info["album"])]
        if data:
            tags["covr"] = [MP4Cover(_square(data), imageformat=MP4Cover.FORMAT_JPEG)]
        tags.save()
        return bool(data)
    except Exception:
        log.exception("No se pudo incrustar la carátula en %s", path)
        return False
