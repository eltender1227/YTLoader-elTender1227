# -*- coding: utf-8 -*-
"""
Validación de enlaces. Lista blanca de plataformas: nada que no sea https y de un dominio conocido llega a yt-dlp.
YouTube se reconstruye en forma canónica (ver yt_sanitizer); el resto se valida con la misma disciplina.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from urllib.parse import urlsplit

from .yt_sanitizer import URLNoPermitida, analizar_url

PLATFORMS = {
    "YouTube": ("youtube.com", "youtu.be"), "TikTok": ("tiktok.com",), "Facebook": ("facebook.com", "fb.watch"),
    "Instagram": ("instagram.com",), "X / Twitter": ("twitter.com", "x.com"), "Reddit": ("reddit.com", "redd.it"),
    "Twitch": ("twitch.tv",), "SoundCloud": ("soundcloud.com", "snd.sc"), "Vimeo": ("vimeo.com",),
    "Dailymotion": ("dailymotion.com", "dai.ly"), "Bilibili": ("bilibili.com", "b23.tv", "bilibili.tv"),
}
_YOUTUBE_HOSTS = ("youtube.com", "youtu.be")
# ASCII imprimible sin espacios ni caracteres de inyección (comillas, <>, `, |, ^, {}, \).
_RE_SAFE = re.compile(r"^[A-Za-z0-9\-._~:/?#&=%+,;@!$*()\[\]]+$")
_RE_URL_IN_TEXT = re.compile(r"https?://[^\s<>\"'`|^{}\\]+")
MAX_URL = 2048


class InvalidURL(ValueError):
    pass


@dataclass(frozen=True)
class UrlInfo:
    url: str
    site: str
    maybe_playlist: bool  # pista para yt-dlp (noplaylist); la lista real la decide la lectura de datos


def _host(url: str) -> str:
    return (urlsplit(url).hostname or "").lower()


def _match(host: str) -> str:
    for name, domains in PLATFORMS.items():
        if any(host == d or host.endswith("." + d) for d in domains):
            return name
    return ""


def validate_url(url: object) -> UrlInfo:
    """Devuelve la URL limpia o lanza InvalidURL."""
    if not isinstance(url, str):
        raise InvalidURL("el enlace no es texto")
    raw = url.strip()
    if not raw or len(raw) > MAX_URL:
        raise InvalidURL("enlace vacío o demasiado largo")
    try:
        host = _host(raw)
    except ValueError as exc:
        raise InvalidURL(f"enlace mal formado ({exc})") from None
    site = _match(host)
    if not site:
        raise InvalidURL(f"plataforma no admitida: {host or '(sin dominio)'}")
    if any(host == d or host.endswith("." + d) for d in _YOUTUBE_HOSTS):
        try:
            info = analizar_url(raw)
        except URLNoPermitida as exc:
            raise InvalidURL(str(exc)) from None
        site = "YouTube Music" if info.host == "music.youtube.com" else "YouTube"
        return UrlInfo(info.url, site, info.tipo in ("playlist", "album"))
    if not _RE_SAFE.match(raw):
        raise InvalidURL("contiene caracteres sospechosos")
    parts = urlsplit(raw)
    try:
        port = parts.port
    except ValueError:
        raise InvalidURL("puerto inválido") from None
    if parts.scheme.lower() != "https":
        raise InvalidURL("solo se aceptan enlaces https://")
    if parts.username is not None or "@" in parts.netloc or port is not None:
        raise InvalidURL("credenciales o puerto en el enlace")
    clean = parts._replace(fragment="").geturl()
    return UrlInfo(clean, site, True)


def extract_urls(text: str) -> list[str]:
    """Saca los enlaces de un texto (p. ej. lo que «Compartir» de otra app envía)."""
    seen: list[str] = []
    for candidate in _RE_URL_IN_TEXT.findall(text or ""):
        candidate = candidate.rstrip(".,;:)!?]")
        if candidate not in seen:
            seen.append(candidate)
    return seen
