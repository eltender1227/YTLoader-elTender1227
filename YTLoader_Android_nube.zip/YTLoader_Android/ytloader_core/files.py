# -*- coding: utf-8 -*-
"""Archivos de una tarea: borrado SEGURO de parciales y utilidades."""
from __future__ import annotations

import os
from pathlib import Path


def _norm(path) -> str:
    return os.path.normcase(os.path.abspath(str(path)))


def inside(path, folder) -> bool:
    try:
        Path(_norm(path)).relative_to(_norm(folder))
        return True
    except ValueError:
        return False


def real_size(files) -> int:
    total = 0
    for file in files:
        try:
            total += os.path.getsize(file)
        except OSError:
            pass
    return total


def discard_partials(job, out_dir) -> list[str]:
    """
    Borra SOLO lo que escribió esta tarea (.part, .ytdl, fragmentos, intermedios y el archivo que ella creó).
    Nunca toca lo que ya existía (job.preexisting) ni nada fuera de su carpeta de destino.
    """
    keep = {_norm(p) for p in job.preexisting}
    candidates: list[str] = []
    for raw in job.artifacts:
        candidates += [raw, raw + ".part", raw + ".ytdl"]
    removed: list[str] = []

    def delete(path: str) -> None:
        if _norm(path) in keep or not inside(path, out_dir):
            return
        try:
            if os.path.isfile(path):
                os.remove(path)
                removed.append(path)
        except OSError:
            pass

    for raw in dict.fromkeys(candidates):
        delete(raw)
    try:
        listing = os.listdir(out_dir) if os.path.isdir(out_dir) else []
    except OSError:
        listing = []
    for raw in job.artifacts:  # fragmentos sueltos «archivo.mp4.part-Frag12»
        prefix = os.path.basename(raw) + ".part-Frag"
        for name in listing:
            if name.startswith(prefix):
                delete(os.path.join(out_dir, name))
    job.artifacts.clear()
    return removed


def unique_path(path: Path) -> Path:
    if not path.exists():
        return path
    for n in range(1, 1000):
        candidate = path.with_name(f"{path.stem} ({n}){path.suffix}")
        if not candidate.exists():
            return candidate
    return path
