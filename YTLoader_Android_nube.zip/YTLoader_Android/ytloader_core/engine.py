# -*- coding: utf-8 -*-
"""
Motor de descargas: usa el MÓDULO yt_dlp (no hay yt-dlp.exe en Android). Sin interfaz: se prueba en cualquier PC.

· Progreso REAL por «progress_hooks» (bytes, velocidad, ETA): no se parsea texto.
· Pausar/cancelar = el hook lanza DownloadCancelled; yt-dlp deja el .part y «continuedl» lo reanuda.
· Directos: se detienen finalizando el .part (MPEG-TS) en un archivo reproducible.
"""
from __future__ import annotations

import logging
import os
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path

from .covers import embed_cover
from .files import discard_partials, real_size, unique_path
from .models import Job
from .options import build_ydl_opts
from .urls import InvalidURL, validate_url

log = logging.getLogger("ytloader.engine")
MAX_ITEMS = 500


class EngineUnavailable(RuntimeError):
    """Falta el módulo yt_dlp."""


class ProbeError(RuntimeError):
    pass


def import_yt_dlp():
    try:
        import yt_dlp

        return yt_dlp
    except ImportError as exc:
        raise EngineUnavailable("Falta el módulo yt-dlp (en el APK lo incluye buildozer.spec → requirements).") from exc


@dataclass
class ProbeResult:
    kind: str  # "video" | "playlist"
    title: str = ""
    site: str = ""
    duration: float = 0.0
    live: bool = False
    items: list = field(default_factory=list)  # playlist: [{"url","title","duration"}]
    entry_count: int = 0
    est_music: float = 0.0
    est_video: dict = field(default_factory=dict)  # altura → bytes


class Control:
    """Canal para pedir a una descarga en curso que se detenga y de qué manera."""

    def __init__(self) -> None:
        self.cancel = threading.Event()
        self.mode: str | None = None  # pause | cancel | discard | stop_live

    def request(self, mode: str) -> None:
        self.mode = mode
        self.cancel.set()


class _Logger:
    """Guarda el último error de yt-dlp (para explicarlo) y no escribe en pantalla."""

    def __init__(self) -> None:
        self.last_error = ""
        self.warnings: list[str] = []

    def debug(self, msg): pass
    def info(self, msg): pass

    def warning(self, msg):
        self.warnings.append(str(msg))

    def error(self, msg):
        self.last_error = str(msg)


def friendly_error(text: str) -> str:
    low = (text or "").lower()
    clean = (text or "error desconocido").replace("ERROR: ", "").strip()
    if "requested format is not available" in low:
        return "No hay un formato disponible para este enlace. Actualiza yt-dlp o prueba otra calidad."
    if "javascript runtime" in low or "js runtime" in low or "n challenge" in low:
        return ("YouTube necesita un runtime de JavaScript que Android no incluye. Prueba con otras plataformas "
                "o usa la versión Termux (con nodejs).")
    if "sign in" in low or "login" in low or "private" in low:
        return "El contenido exige iniciar sesión o es privado."
    return clean if len(clean) <= 160 else clean[:157] + "…"


def _estimate(info: dict, kind: str, height: int) -> float:
    best = 0.0
    for fmt in info.get("formats") or []:
        size = fmt.get("filesize") or fmt.get("filesize_approx") or 0
        if not size:
            continue
        audio_only = fmt.get("vcodec") in (None, "none") and fmt.get("acodec") not in (None, "none")
        muxed = fmt.get("vcodec") not in (None, "none") and fmt.get("acodec") not in (None, "none")
        if kind == "music" and audio_only:
            best = max(best, float(size))
        elif kind == "video" and muxed and (not height or (fmt.get("height") or 0) <= height):
            best = max(best, float(size))
    return best


class DownloadEngine:
    def __init__(self, yt_dlp_module=None, ffmpeg: str | None = None) -> None:
        self._yt = yt_dlp_module
        self.ffmpeg = ffmpeg

    @property
    def yt_dlp(self):
        if self._yt is None:
            self._yt = import_yt_dlp()
        return self._yt

    # ------------------------------------------------------------ lectura de datos
    def probe(self, url: str, maybe_playlist: bool = True) -> ProbeResult:
        logger = _Logger()
        opts = {"quiet": True, "no_warnings": True, "skip_download": True, "extract_flat": "in_playlist",
                "noplaylist": not maybe_playlist, "socket_timeout": 20, "logger": logger}
        try:
            with self.yt_dlp.YoutubeDL(opts) as ydl:
                info = ydl.extract_info(url, download=False)
        except EngineUnavailable:
            raise
        except Exception as exc:
            raise ProbeError(friendly_error(logger.last_error or str(exc))) from exc
        if not isinstance(info, dict):
            raise ProbeError("No se pudieron leer los datos del enlace.")
        if info.get("_type") == "playlist" or info.get("entries") is not None:
            entries = list(info.get("entries") or [])
            items, seen = [], set()
            for entry in entries[:MAX_ITEMS]:
                if not isinstance(entry, dict):
                    continue
                link = entry.get("url") or entry.get("webpage_url")
                if not link and str(entry.get("ie_key", "")).lower() == "youtube" and entry.get("id"):
                    link = f"https://www.youtube.com/watch?v={entry['id']}"
                try:
                    clean = validate_url(link).url
                except InvalidURL:
                    continue  # elementos con enlaces no permitidos se ignoran
                if clean in seen:
                    continue
                seen.add(clean)
                items.append({"url": clean, "title": str(entry.get("title") or entry.get("id") or clean),
                              "duration": float(entry.get("duration") or 0)})
            return ProbeResult("playlist", title=str(info.get("title") or "Lista"), items=items,
                               entry_count=len(entries))
        live = bool(info.get("is_live")) or info.get("live_status") == "is_live"
        heights = {0, 1080, 720, 480, 360}
        return ProbeResult("video", title=str(info.get("track") or info.get("title") or ""),
                           duration=float(info.get("duration") or 0), live=live,
                           est_music=_estimate(info, "music", 0),
                           est_video={h: _estimate(info, "video", h) for h in heights})

    # ------------------------------------------------------------ descarga
    def download(self, job: Job, out_dir, control: Control, notify=None) -> str:
        """Devuelve 'ok' | 'error' | 'paused' | 'cancelled'. Bloquea: llamar desde un hilo."""
        out_dir = Path(out_dir)
        try:
            out_dir.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            job.error = f"No se pudo usar la carpeta de destino: {exc}"
            return "error"
        yt = self.yt_dlp
        job.base_bytes = job.loaded = job.total = 0.0
        job.error, job.validated, job.cover_embedded, job.files = "", False, False, []
        started = time.time()
        before = {p.name for p in out_dir.iterdir() if p.is_file()}
        throttle = {"last": 0.0}
        logger = _Logger()
        cancel_exc = getattr(getattr(yt, "utils", None), "DownloadCancelled", None) or _Cancelled

        def hook(d: dict) -> None:
            if control.cancel.is_set():
                raise cancel_exc()
            self._on_hook(job, d, before, started, notify, throttle)

        opts = build_ydl_opts(job, out_dir, ffmpeg=self.ffmpeg, hook=hook, logger=logger)
        info: dict = {}
        try:
            with yt.YoutubeDL(opts) as ydl:
                info = ydl.extract_info(job.url, download=True) or {}
                files = self._collect_files(ydl, info)
        except Exception as exc:  # noqa: BLE001
            return self._on_exception(exc, job, control, logger, out_dir)
        if control.cancel.is_set() and job.live and control.mode == "stop_live":
            return self._finish_live(job, out_dir)
        bad = [f for f in files if not os.path.isfile(f) or os.path.getsize(f) <= 0 or os.path.exists(f + ".part")]
        if not files or bad:
            job.error = "El archivo está incompleto o vacío." if bad else "yt-dlp no generó ningún archivo."
            return "error"
        job.files = files
        job.validated = True
        if job.kind == "music" and not self.ffmpeg and not job.live:
            job.cover_embedded = embed_cover(files[0], info)
        return "ok"

    @staticmethod
    def _on_hook(job: Job, d: dict, before: set, started: float, notify, throttle: dict) -> None:
        for path in (d.get("tmpfilename"), d.get("filename")):
            if path and path not in job.artifacts and path not in job.preexisting:
                existed = os.path.basename(path) in before and not path.endswith(".part")
                (job.preexisting if existed else job.artifacts).append(path)
        status = d.get("status")
        if status == "downloading":
            total = d.get("total_bytes") or d.get("total_bytes_estimate") or 0
            job.loaded = float(d.get("downloaded_bytes") or 0)
            job.total = float(total)
            job.speed = float(d.get("speed") or 0)
            job.eta = float(d.get("eta") or 0)
            job.progress = (job.loaded / total * 100) if total else 0.0
            if job.live:
                job.rec_seconds = float(d.get("elapsed") or (time.time() - started))
            now = time.monotonic()
            if notify is not None and now - throttle["last"] >= 0.25:
                throttle["last"] = now
                notify(job)
        elif status == "finished":  # termina UNA corriente (video o audio): se acumula
            job.base_bytes += float(d.get("total_bytes") or d.get("downloaded_bytes") or 0)
            job.loaded = job.total = job.speed = job.eta = 0.0

    @staticmethod
    def _collect_files(ydl, info: dict) -> list[str]:
        files = [rd.get("filepath") or rd.get("_filename") for rd in (info.get("requested_downloads") or [])]
        files = [f for f in files if f]
        if not files and info:
            try:
                candidate = ydl.prepare_filename(info)
                if os.path.isfile(candidate):
                    files = [candidate]
            except Exception:
                pass
        return files

    def _on_exception(self, exc, job: Job, control: Control, logger: _Logger, out_dir: Path) -> str:
        if control.cancel.is_set():  # cualquier excepción tras pedir parada se interpreta como parada
            if control.mode == "stop_live" and job.live:
                return self._finish_live(job, out_dir)
            if control.mode == "discard":
                discard_partials(job, out_dir)
                return "cancelled"
            return "paused" if control.mode == "pause" else "cancelled"
        job.error = friendly_error(logger.last_error or str(exc))
        log.warning("Descarga fallida (%s): %s", job.url, exc)
        return "error"

    @staticmethod
    def _finish_live(job: Job, out_dir: Path) -> str:
        """Directo detenido: el .part (MPEG-TS) pasa a archivo final .ts; solo se acepta si tiene contenido."""
        parts = [p for raw in job.artifacts for p in (raw + ".part", raw) if p.endswith(".part") and os.path.isfile(p)
                 and os.path.getsize(p) > 0]
        if not parts:
            job.error = "No había nada grabado que conservar."
            return "cancelled"
        part = max(parts, key=os.path.getsize)
        final = unique_path(Path(part[:-5]).with_suffix(".ts"))
        try:
            os.replace(part, final)
        except OSError as exc:
            job.error = f"No se pudo finalizar la grabación: {exc}"
            return "error"
        job.files = [str(final)]
        job.artifacts.append(str(final))
        job.validated = real_size(job.files) > 0
        return "ok" if job.validated else "error"


class _Cancelled(Exception):
    """Respaldo si el módulo yt_dlp no expone DownloadCancelled."""
