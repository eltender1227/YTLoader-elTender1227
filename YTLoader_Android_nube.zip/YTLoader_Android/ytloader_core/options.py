# -*- coding: utf-8 -*-
"""Opciones de yt-dlp para música y video. Sin ffmpeg (lo normal en Android) se usan formatos ya mezclados."""
from __future__ import annotations

from pathlib import Path

MUSIC_QUALITIES = {"max": "Máxima", "320": "320 kbps", "192": "192 kbps", "128": "128 kbps"}
VIDEO_QUALITIES = {"max": "Mejor disponible", "1080": "1080p", "720": "720p", "480": "480p", "360": "360p"}


def video_height(quality: str) -> int:
    return int(quality) if quality.isdigit() else 0


def build_ydl_opts(job, out_dir: Path, *, ffmpeg: str | None, hook, logger) -> dict:
    """
    ffmpeg=None (típico en Android):
      · música → mejor audio m4a/AAC tal cual (sin convertir a MP3); la carátula la incrusta mutagen (covers.py).
      · video  → mejor formato YA MEZCLADO (en YouTube suele ser ≤ 720p). Para 1080p+ hace falta ffmpeg.
    ffmpeg=ruta: se usa el mismo flujo que la versión de escritorio (MP3 + carátula + metadatos; MP4 mezclado).
    """
    opts: dict = {
        "outtmpl": str(Path(out_dir) / "%(title).120s.%(ext)s"),
        "noplaylist": True,  # cada tarea es UN elemento; las listas se expanden en paquetes antes de descargar
        "continuedl": True,  # reanudar desde el .part (así funciona «Reanudar»)
        "retries": 5, "fragment_retries": 5, "socket_timeout": 20,
        "windowsfilenames": True, "overwrites": False,
        "quiet": True, "no_warnings": True, "noprogress": True,
        "progress_hooks": [hook], "logger": logger,
    }
    if ffmpeg:
        opts["ffmpeg_location"] = ffmpeg
    height = video_height(job.quality)
    if job.live:
        opts.update({"live_from_start": False, "hls_use_mpegts": True,
                     "format": (f"b[height<={height}]/b/bv*+ba" if height else "b/bv*+ba")})
        return opts
    if job.kind == "music":
        if ffmpeg:
            quality = job.quality if job.quality in MUSIC_QUALITIES else "max"
            opts["format"] = "bestaudio/best"
            opts["writethumbnail"] = True
            opts["postprocessors"] = [
                {"key": "FFmpegExtractAudio", "preferredcodec": "mp3",
                 "preferredquality": "0" if quality == "max" else quality},
                {"key": "FFmpegThumbnailsConvertor", "format": "jpg", "when": "before_dl"},
                {"key": "FFmpegMetadata", "add_metadata": True},
                {"key": "EmbedThumbnail"},
            ]
        else:
            opts["format"] = "bestaudio[ext=m4a]/bestaudio/best"
    else:
        if ffmpeg:
            opts["format"] = (f"bv*[height<={height}]+ba/b[height<={height}]/b" if height else "bv*+ba/b")
            opts["merge_output_format"] = "mp4"
        else:
            opts["format"] = (f"b[ext=mp4][height<={height}]/b[height<={height}]/b[ext=mp4]/b" if height
                              else "b[ext=mp4]/b")
    return opts
