# -*- coding: utf-8 -*-
"""Modelo de datos: tareas (Job) y paquetes (listas de reproducción)."""
from __future__ import annotations

from dataclasses import dataclass, field

PENDING, RUNNING, DONE, ERROR, PAUSED, CANCELLED = "pending", "running", "done", "error", "paused", "cancelled"
STATUS_LABELS = {PENDING: "⏳ Pendiente", RUNNING: "⬇ Descargando", DONE: "✅ Completado", ERROR: "❌ Error",
                 PAUSED: "⏸ Pausado", CANCELLED: "⏹ Cancelado"}


@dataclass(eq=False)
class Job:
    uid: int
    url: str
    kind: str  # "music" | "video"
    quality: str = "max"
    status: str = PENDING
    title: str = ""
    site: str = ""
    duration: float = 0.0
    live: bool = False
    include: bool = True  # dentro de un paquete: ¿se descarga?
    meta_state: str = "loading"  # loading | ok | fail
    package: "Package | None" = field(default=None, repr=False)
    est_bytes: float = 0.0  # tamaño estimado por los metadatos (0 = desconocido)
    # Progreso real (lo informa yt-dlp)
    progress: float = 0.0
    speed: float = 0.0
    eta: float = 0.0
    loaded: float = 0.0
    total: float = 0.0
    base_bytes: float = 0.0  # bytes de corrientes ya terminadas (video y audio van por separado)
    rec_seconds: float = 0.0  # directo: tiempo grabado
    # Archivos
    files: list = field(default_factory=list)  # resultado final
    artifacts: list = field(default_factory=list)  # lo que ESTA tarea escribe (.part, intermedios…)
    preexisting: list = field(default_factory=list)  # ya existía: NUNCA se borra
    error: str = ""
    validated: bool = False
    cover_embedded: bool = False


@dataclass(eq=False)
class Package:
    """Lista de reproducción: una carpeta con sus canciones/videos."""

    pid: int
    name: str
    kind: str
    source_url: str = ""
    items: list = field(default_factory=list)
    expanded: bool = False


def job_total_bytes(job: Job) -> float:
    return max(job.est_bytes, job.base_bytes + job.total)


def job_loaded_bytes(job: Job) -> float:
    return job.base_bytes + job.loaded


def human_size(num: float, decimals: int = 1) -> str:
    size = float(num or 0)
    units = ("B", "KiB", "MiB", "GiB", "TiB")
    index = 0
    while size >= 1024 and index < len(units) - 1:
        size /= 1024
        index += 1
    return f"{size:.0f} B" if index == 0 else f"{size:.{decimals}f} {units[index]}"


def human_speed(bps: float) -> str:
    return human_size(bps, 2) + "/s"


def human_eta(seconds: float) -> str:
    total = max(int(seconds or 0), 0)
    hours, rest = divmod(total, 3600)
    minutes, secs = divmod(rest, 60)
    if hours:
        return f"{hours}h:{minutes:02d}m:{secs:02d}s"
    return f"{minutes}m:{secs:02d}s" if minutes else f"{secs}s"


def hms(seconds: float) -> str:
    total = max(int(seconds or 0), 0)
    return f"{total // 3600:02d}:{total % 3600 // 60:02d}:{total % 60:02d}"
