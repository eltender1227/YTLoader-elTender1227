"""YTLoader (Android): núcleo SIN interfaz ni APIs de Windows. Se prueba en cualquier ordenador."""
__version__ = "0.1.0"
