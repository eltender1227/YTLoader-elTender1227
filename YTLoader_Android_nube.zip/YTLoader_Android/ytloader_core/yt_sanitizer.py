# -*- coding: utf-8 -*-
"""
Validación ESTRICTA de URLs de YouTube / YouTube Music.
· Lista blanca de hosts exactos (sin «endswith» ni «contains»): youtube.com, www./m./music.youtube.com, youtu.be.
· Solo https; sin credenciales, sin puerto, sin caracteres raros (espacios, control, comillas, \\, Unicode).
· Se valida la ruta y los parámetros con regex y se RECONSTRUYE una URL canónica solo con lo verificado (v=, list=).
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from urllib.parse import parse_qs, urlsplit

MAX_URL = 2048
HOSTS_WEB = frozenset({"youtube.com", "www.youtube.com", "m.youtube.com"})
HOST_MUSIC = "music.youtube.com"
HOST_CORTO = "youtu.be"

_RE_CARACTERES = re.compile(r"^[A-Za-z0-9\-._~:/?#&=%+,;@]+$")
_RE_VIDEO_ID = re.compile(r"^[A-Za-z0-9_-]{11}$")
_RE_LISTA_ID = re.compile(r"^[A-Za-z0-9_-]{10,64}$")
_RE_RUTA_CORTA = re.compile(r"^/([A-Za-z0-9_-]{11})/?$")
_RE_RUTA_ID = re.compile(r"^/(shorts|live|embed)/([A-Za-z0-9_-]{11})/?$")
_RE_RUTA_BROWSE = re.compile(r"^/browse/([A-Za-z0-9_-]{5,64})/?$")


class URLNoPermitida(ValueError):
    """La URL no pertenece a YouTube / YouTube Music o tiene caracteres sospechosos."""


@dataclass(frozen=True)
class UrlSanitizada:
    url: str
    tipo: str  # video | short | directo | embed | playlist | album
    host: str
    video_id: str = ""
    list_id: str = ""


def _parametro(consulta, nombre, patron):
    valores = consulta.get(nombre)
    if valores is None:
        return None
    if len(valores) != 1:
        raise URLNoPermitida(f"parámetro «{nombre}» repetido")
    if not patron.match(valores[0]):
        raise URLNoPermitida(f"parámetro «{nombre}» con formato inválido")
    return valores[0]


def analizar_url(url: object) -> UrlSanitizada:
    """Devuelve la forma canónica o lanza URLNoPermitida."""
    if not isinstance(url, str):
        raise URLNoPermitida("la URL no es texto")
    crudo = url.strip()
    if not crudo:
        raise URLNoPermitida("URL vacía")
    if len(crudo) > MAX_URL:
        raise URLNoPermitida("URL demasiado larga")
    if not _RE_CARACTERES.match(crudo):
        raise URLNoPermitida("contiene caracteres sospechosos")
    try:
        partes = urlsplit(crudo)
        puerto = partes.port
        consulta = parse_qs(partes.query, keep_blank_values=True, max_num_fields=20)
    except ValueError as exc:
        raise URLNoPermitida(f"URL mal formada ({exc})") from None
    if partes.scheme.lower() != "https":
        raise URLNoPermitida("solo se aceptan enlaces https://")
    host = (partes.hostname or "").lower()
    if not host:
        raise URLNoPermitida("sin dominio")
    if partes.username is not None or partes.password is not None or "@" in partes.netloc:
        raise URLNoPermitida("credenciales en la URL")
    if puerto is not None:
        raise URLNoPermitida("puerto explícito no permitido")
    if partes.netloc.lower() != host:
        raise URLNoPermitida("dominio con formato extraño")

    ruta = partes.path
    lista = _parametro(consulta, "list", _RE_LISTA_ID)
    if host == HOST_CORTO:
        m = _RE_RUTA_CORTA.match(ruta)
        if not m:
            raise URLNoPermitida("ruta no válida en youtu.be")
        return UrlSanitizada(f"https://{HOST_CORTO}/{m.group(1)}" + (f"?list={lista}" if lista else ""), "video",
                             host, m.group(1), lista or "")
    if host in HOSTS_WEB:
        if ruta == "/watch":
            video = _parametro(consulta, "v", _RE_VIDEO_ID)
            if not video:
                raise URLNoPermitida("falta el identificador de video (v=)")
            return UrlSanitizada(f"https://www.youtube.com/watch?v={video}" + (f"&list={lista}" if lista else ""),
                                 "video", host, video, lista or "")
        m = _RE_RUTA_ID.match(ruta)
        if m:
            tipos = {"shorts": "short", "live": "directo", "embed": "embed"}
            return UrlSanitizada(f"https://www.youtube.com/{m.group(1)}/{m.group(2)}", tipos[m.group(1)], host,
                                 m.group(2))
        if ruta == "/playlist":
            if not lista:
                raise URLNoPermitida("falta el identificador de lista (list=)")
            return UrlSanitizada(f"https://www.youtube.com/playlist?list={lista}", "playlist", host, "", lista)
        raise URLNoPermitida("ruta no permitida en youtube.com")
    if host == HOST_MUSIC:
        if ruta == "/watch":
            video = _parametro(consulta, "v", _RE_VIDEO_ID)
            if not video:
                raise URLNoPermitida("falta el identificador de pista (v=)")
            return UrlSanitizada(f"https://{HOST_MUSIC}/watch?v={video}" + (f"&list={lista}" if lista else ""),
                                 "video", host, video, lista or "")
        if ruta == "/playlist":
            if not lista:
                raise URLNoPermitida("falta el identificador de lista (list=)")
            return UrlSanitizada(f"https://{HOST_MUSIC}/playlist?list={lista}", "playlist", host, "", lista)
        m = _RE_RUTA_BROWSE.match(ruta)
        if m:
            return UrlSanitizada(f"https://{HOST_MUSIC}/browse/{m.group(1)}", "album", host)
        raise URLNoPermitida("ruta no permitida en music.youtube.com")
    raise URLNoPermitida(f"dominio no autorizado: {host}")
