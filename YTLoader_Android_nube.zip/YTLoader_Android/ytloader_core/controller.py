# -*- coding: utf-8 -*-
"""
Controlador (sin Kivy): lista de tareas y paquetes, hilos de lectura y de descarga, pausa/cancelación y progreso global.
La interfaz solo consulta `version` (cambia con cada novedad) y llama a estos métodos.
"""
from __future__ import annotations

import itertools
import json
import os
import re
import tempfile
import threading
from collections import deque
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from . import models as M
from .engine import Control, DownloadEngine, ProbeError, ProbeResult
from .files import discard_partials, inside, real_size
from .options import MUSIC_QUALITIES, VIDEO_QUALITIES, video_height
from .urls import InvalidURL, extract_urls, validate_url

DEFAULT_SETTINGS = {"theme": "dark", "kind": "music", "music_quality": "max", "video_quality": "max",
                    "download_dir": ""}


def safe_dirname(name: str, fallback: str = "Lista") -> str:
    cleaned = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", name).strip(" .")
    return cleaned[:80] or fallback


class Controller:
    def __init__(self, engine: DownloadEngine, default_dir: str, settings_path: str | None = None) -> None:
        self.engine = engine
        self.default_dir = default_dir
        self.settings_path = settings_path
        self.settings = self._load_settings()
        self.jobs: dict[int, M.Job] = {}
        self.packages: dict[int, M.Package] = {}
        self.version = 0
        self.log_lines: deque[str] = deque(maxlen=300)
        self.notices: deque[dict] = deque()  # avisos para la interfaz (fin de tarea, errores…)
        self.batch: list[M.Job] = []
        self.last_batch: dict = {}
        self.pausing = False
        self._uid, self._pid = itertools.count(1), itertools.count(1)
        self._lock = threading.RLock()
        self._pool = ThreadPoolExecutor(max_workers=2, thread_name_prefix="probe")
        self._thread: threading.Thread | None = None
        self._control: Control | None = None
        self._peak = 0.0

    # ------------------------------------------------------------------ ajustes
    def _load_settings(self) -> dict:
        data = dict(DEFAULT_SETTINGS)
        if self.settings_path and os.path.isfile(self.settings_path):
            try:
                with open(self.settings_path, encoding="utf-8") as fh:
                    saved = json.load(fh)
                if isinstance(saved, dict):
                    if saved.get("theme") in ("dark", "light"):
                        data["theme"] = saved["theme"]
                    if saved.get("kind") in ("music", "video"):
                        data["kind"] = saved["kind"]
                    if saved.get("music_quality") in MUSIC_QUALITIES:
                        data["music_quality"] = saved["music_quality"]
                    if saved.get("video_quality") in VIDEO_QUALITIES:
                        data["video_quality"] = saved["video_quality"]
                    if isinstance(saved.get("download_dir"), str):
                        data["download_dir"] = saved["download_dir"]
            except (OSError, ValueError):
                pass
        return data

    def save_settings(self) -> None:
        if not self.settings_path:
            return
        try:
            os.makedirs(os.path.dirname(self.settings_path) or ".", exist_ok=True)
            with tempfile.NamedTemporaryFile("w", encoding="utf-8", dir=os.path.dirname(self.settings_path) or ".",
                                             delete=False, suffix=".tmp") as tmp:
                json.dump(self.settings, tmp, ensure_ascii=False, indent=2)
                name = tmp.name
            os.replace(name, self.settings_path)  # escritura atómica
        except OSError:
            pass

    # ------------------------------------------------------------------ utilidades
    def touch(self, *_args) -> None:
        self.version += 1

    def log(self, text: str) -> None:
        self.log_lines.append(text)
        self.touch()

    def out_dir_for(self, job: M.Job) -> Path:
        base = Path(self.settings.get("download_dir") or self.default_dir)
        base = base / ("Musica" if job.kind == "music" else "Videos")
        if job.package is not None:
            base = base / safe_dirname(job.package.name)
        return base

    def quality_for(self, kind: str) -> str:
        return self.settings["music_quality" if kind == "music" else "video_quality"]

    @property
    def running(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    # ------------------------------------------------------------------ añadir enlaces
    def add_text(self, text: str, kind: str | None = None) -> tuple[int, list[str]]:
        """Añade los enlaces de un texto. Devuelve (añadidos, motivos de rechazo)."""
        kind = kind if kind in ("music", "video") else self.settings["kind"]
        urls = extract_urls(text) or ([text.strip()] if text.strip() else [])
        if not urls:
            return 0, ["No se encontró ningún enlace."]
        added, errors = 0, []
        for raw in urls:
            try:
                info = validate_url(raw)
            except InvalidURL as exc:
                errors.append(f"{raw[:60]}: {exc}")
                continue
            with self._lock:
                if any(j.url == info.url and j.kind == kind and j.status != M.DONE for j in self.jobs.values()) or \
                        any(p.source_url == info.url and p.kind == kind for p in self.packages.values()):
                    errors.append(f"{info.url[:60]}: ya está en la lista")
                    continue
                job = M.Job(uid=next(self._uid), url=info.url, kind=kind, quality=self.quality_for(kind), site=info.site)
                self.jobs[job.uid] = job
            added += 1
            self._pool.submit(self._probe_job, job, info.maybe_playlist)
        self.touch()
        return added, errors

    def _probe_job(self, job: M.Job, maybe_playlist: bool) -> None:
        try:
            result = self.engine.probe(job.url, maybe_playlist)
        except (ProbeError, Exception) as exc:  # noqa: BLE001  (también EngineUnavailable)
            if job.uid in self.jobs:
                job.meta_state = "fail"
                job.error = str(exc)
                self.log(f"⚠ No se pudieron leer los datos de {job.url}: {exc}")
            return
        with self._lock:
            if job.uid not in self.jobs:
                return
            if result.kind == "playlist":
                self._to_package(job, result)
            else:
                self._apply_probe(job, result)
        self.touch()

    def _apply_probe(self, job: M.Job, result: ProbeResult) -> None:
        job.meta_state = "ok"
        job.title = result.title or job.url
        job.duration = result.duration
        job.live = result.live
        job.est_bytes = result.est_music if job.kind == "music" else result.est_video.get(video_height(job.quality), 0)

    def _to_package(self, job: M.Job, result: ProbeResult) -> None:
        """Una lista de reproducción se convierte en paquete (carpeta) con una tarea por elemento."""
        if not result.items or len(result.items) * 2 < max(result.entry_count, 1) or job.status != M.PENDING:
            job.meta_state = "fail"
            job.error = "La lista está vacía o no se pudieron leer sus elementos."
            return
        package = M.Package(pid=next(self._pid), name=result.title or "Lista", kind=job.kind, source_url=job.url)
        for item in result.items:
            child = M.Job(uid=next(self._uid), url=item["url"], kind=job.kind, quality=job.quality,
                          title=item["title"], duration=item["duration"], meta_state="ok", package=package,
                          site=job.site)
            self.jobs[child.uid] = child
            package.items.append(child)
        self.packages[package.pid] = package
        self.jobs.pop(job.uid, None)
        extra = f" (primeros {len(result.items)} de {result.entry_count})" if result.entry_count > len(result.items) else ""
        self.log(f"📁 «{package.name}»: {len(result.items)} elementos{extra}.")

    # ------------------------------------------------------------------ descarga
    def start(self, jobs: list[M.Job] | None = None) -> bool:
        if self.running:
            return False
        with self._lock:
            candidates = list(self.jobs.values()) if jobs is None else jobs
            pending = [j for j in candidates if j.status != M.DONE and j.include and j.uid in self.jobs]
            if not pending:
                return False
            for job in pending:
                job.status, job.progress, job.speed, job.eta, job.error = M.PENDING, 0.0, 0.0, 0.0, ""
            self.batch = pending
            self.pausing = False
            self._peak = 0.0
            self._control = Control()
            self._thread = threading.Thread(target=self._run, args=(list(pending), self._control), daemon=True)
        self._thread.start()
        self.log(f"=== Iniciando {len(pending)} descarga(s) ===")
        return True

    def _run(self, batch: list[M.Job], control: Control) -> None:
        finished: list[M.Job] = []
        try:
            for job in batch:
                if control.cancel.is_set():
                    break
                if job.uid not in self.jobs:
                    continue
                job.status = M.RUNNING
                self.touch()
                try:
                    result = self.engine.download(job, self.out_dir_for(job), control, notify=self.touch)
                except Exception as exc:  # noqa: BLE001
                    job.error, result = str(exc), "error"
                job.status = {"ok": M.DONE, "paused": M.PAUSED, "cancelled": M.CANCELLED}.get(result, M.ERROR)
                job.speed = job.eta = 0.0
                if result == "ok":
                    job.progress = 100.0
                    finished.append(job)
                elif result == "error":
                    self.log(f"❌ {job.title or job.url}: {job.error}")
                self.touch()
        finally:
            if control.mode == "discard":
                for job in batch:
                    if job.status != M.DONE:
                        discard_partials(job, self.out_dir_for(job))
                        job.status, job.progress, job.base_bytes, job.loaded, job.total = M.PENDING, 0.0, 0.0, 0.0, 0.0
            self.last_batch = {"finished": finished, "paused": control.mode == "pause",
                               "cancelled": control.cancel.is_set() and control.mode != "pause",
                               "failed": [j for j in batch if j.status == M.ERROR]}
            self.notices.append({"type": "batch", **self.last_batch})
            self.touch()

    def pause(self) -> str:
        """'' si se pidió la pausa, o el motivo por el que no se puede."""
        if not self.running or self._control is None:
            return "No hay descargas en curso."
        if any(j.live and j.status == M.RUNNING for j in self.batch):
            return "Un directo no se puede pausar. Usa «Detener» para terminar y conservar lo grabado."
        self.pausing = True
        self._control.request("pause")
        return ""

    def resume(self) -> bool:
        return self.start([j for j in self.jobs.values() if j.status in (M.PAUSED, M.PENDING) and j.include])

    def stop(self) -> None:
        """Detener = cancelar. Un directo en grabación se finaliza conservando lo grabado."""
        if self.running and self._control is not None:
            self._control.request("stop_live")

    def cancel_and_discard(self) -> None:
        if self.running and self._control is not None:
            self._control.request("discard")
        else:
            for job in self.jobs.values():
                if job.status != M.DONE and job.artifacts:
                    discard_partials(job, self.out_dir_for(job))
                    job.status, job.progress, job.base_bytes, job.loaded, job.total = M.PENDING, 0.0, 0.0, 0.0, 0.0
            self.touch()

    # ------------------------------------------------------------------ lista
    def remove(self, job: M.Job) -> bool:
        if job.status == M.RUNNING:
            return False
        with self._lock:
            self.jobs.pop(job.uid, None)
            if job.package is not None and job in job.package.items:
                job.package.items.remove(job)
        self.touch()
        return True

    def remove_package(self, package: M.Package) -> bool:
        if any(j.status == M.RUNNING for j in package.items):
            return False
        with self._lock:
            for job in list(package.items):
                self.jobs.pop(job.uid, None)
            package.items.clear()
            self.packages.pop(package.pid, None)
        self.touch()
        return True

    def clear_done(self) -> None:
        for job in [j for j in self.jobs.values() if j.status == M.DONE]:
            self.remove(job)
        for package in [p for p in self.packages.values() if not p.items]:
            self.packages.pop(package.pid, None)

    def delete_recording(self, job: M.Job) -> int:
        """Elimina SOLO la grabación recién creada y sus temporales (nunca lo que ya existía)."""
        out_dir = self.out_dir_for(job)
        keep = {os.path.normcase(os.path.abspath(p)) for p in job.preexisting}
        removed = 0
        for path in job.files:
            if os.path.normcase(os.path.abspath(path)) in keep or not inside(path, out_dir):
                continue
            try:
                os.remove(path)
                removed += 1
            except OSError:
                pass
        removed += len(discard_partials(job, out_dir))
        self.remove(job)
        return removed

    # ------------------------------------------------------------------ progreso global
    def global_progress(self, final: bool = False) -> tuple[float | None, str]:
        """(porcentaje | None, texto). None = indeterminado: no se conocen todos los tamaños (no se inventa)."""
        batch = [j for j in self.batch if j.uid in self.jobs and j.include]
        if not batch:
            return 0.0, ""
        done = sum(1 for j in batch if j.status == M.DONE)
        running = [j for j in batch if j.status == M.RUNNING]
        speed = sum(j.speed for j in running)
        if all(not j.live and M.job_total_bytes(j) > 0 for j in batch):
            total = sum(M.job_total_bytes(j) for j in batch)
            loaded = sum(M.job_total_bytes(j) if j.status == M.DONE else min(M.job_loaded_bytes(j), M.job_total_bytes(j))
                         for j in batch)
            pct = loaded / total * 100
            self._peak = pct if final else max(pct, self._peak)  # nunca retrocede mientras se descarga
            eta = (total - loaded) / speed if speed > 0 else 0
            text = (f"{self._peak:.1f}% · {M.human_size(loaded)} / {M.human_size(total)} · {M.human_speed(speed)}"
                    + (f" · ETA {M.human_eta(eta)}" if eta > 0 else "") + f" · {done}/{len(batch)}")
            return self._peak, text
        extra = f" · 🔴 {M.hms(running[0].rec_seconds)}" if running and running[0].live else ""
        return None, f"{done}/{len(batch)} archivos · {M.human_speed(speed)} · tamaño total desconocido{extra}"

    def describe_batch(self, batch: dict) -> list[dict]:
        """Qué debe anunciar la interfaz al terminar una tarea (solo lo realmente completado y validado)."""
        out: list[dict] = []
        for job in batch.get("finished", []):
            if job.live and job.validated:
                out.append({"type": "live", "job": job, "files": job.files, "size": real_size(job.files)})
        normal = [j for j in batch.get("finished", []) if not j.live]
        if normal and not batch.get("cancelled") and not batch.get("paused"):
            files = [f for j in normal for f in j.files if os.path.isfile(f)]
            if files:
                out.append({"type": "complete", "files": files, "size": real_size(files),
                            "folder": os.path.dirname(files[0]), "failed": len(batch.get("failed", []))})
        failed = batch.get("failed", [])
        if failed and not out and not batch.get("cancelled") and not batch.get("paused"):
            out.append({"type": "error", "jobs": failed})
        return out
