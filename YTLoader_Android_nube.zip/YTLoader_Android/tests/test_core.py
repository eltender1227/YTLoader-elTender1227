import json, os, sys, tempfile, time, types
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent)); sys.path.insert(0, str(Path(__file__).resolve().parent))
import fake_ytdlp
from ytloader_core import models as M, covers
from ytloader_core.controller import Controller
from ytloader_core.engine import DownloadEngine, Control, friendly_error
from ytloader_core.files import discard_partials
from ytloader_core.options import build_ydl_opts

FAILS = []
def check(cond, msg):
    print(("  OK   " if cond else "  ✗✗   ") + msg)
    if not cond: FAILS.append(msg)
def wait(pred, timeout=15):
    end = time.time() + timeout
    while time.time() < end:
        if pred(): return True
        time.sleep(0.03)
    return False
def new_ctl(tmp, **kw):
    return Controller(DownloadEngine(fake_ytdlp, ffmpeg=kw.get("ffmpeg")), str(tmp / "dl"), str(tmp / "cfg" / "settings.json"))
def idle(c): return wait(lambda: not c.running)

with tempfile.TemporaryDirectory() as td:
    tmp = Path(td)
    print("== 1. Opciones de yt-dlp ==")
    job = M.Job(uid=1, url="u", kind="music", quality="max"); noop = lambda d: None
    o = build_ydl_opts(job, tmp, ffmpeg=None, hook=noop, logger=None)
    check(o["format"].startswith("bestaudio[ext=m4a]") and "postprocessors" not in o and o["continuedl"], "música sin ffmpeg → m4a tal cual, sin postprocesadores, con reanudación")
    o = build_ydl_opts(job, tmp, ffmpeg="/x/ffmpeg", hook=noop, logger=None)
    keys = [p["key"] for p in o["postprocessors"]]
    check(keys[0] == "FFmpegExtractAudio" and "EmbedThumbnail" in keys and o["writethumbnail"], "música con ffmpeg → MP3 + carátula + metadatos")
    v = M.Job(uid=2, url="u", kind="video", quality="720")
    check("height<=720" in build_ydl_opts(v, tmp, ffmpeg=None, hook=noop, logger=None)["format"] and "merge_output_format" not in build_ydl_opts(v, tmp, ffmpeg=None, hook=noop, logger=None), "video sin ffmpeg → formato YA mezclado ≤720p")
    check(build_ydl_opts(v, tmp, ffmpeg="/f", hook=noop, logger=None)["merge_output_format"] == "mp4", "video con ffmpeg → mezcla a MP4")
    lv = M.Job(uid=3, url="u", kind="video", quality="max", live=True)
    check(build_ydl_opts(lv, tmp, ffmpeg=None, hook=noop, logger=None)["hls_use_mpegts"] is True, "directo → MPEG-TS (el .part es reproducible)")

    print("== 2. Añadir enlaces y leer datos ==")
    c = new_ctl(tmp)
    n, errs = c.add_text("mira https://youtu.be/dQw4w9WgXcQ y https://evil.com/x y https://vimeo.com/123 y https://youtu.be/dQw4w9WgXcQ", "music")
    check(n == 2 and len(errs) == 1, f"2 válidos (el repetido en el texto se une); rechazado: {[e[:40] for e in errs]}")
    check(wait(lambda: all(j.meta_state == "ok" for j in c.jobs.values())), "datos leídos (título, duración, tamaño estimado)")
    j = list(c.jobs.values())[0]; check(j.est_bytes == 5_000_000 and j.duration == 200, f"estimación música = {j.est_bytes:.0f} B")
    check(c.add_text("", "music")[0] == 0 and c.add_text("hola", "music")[0] == 0, "texto sin enlaces → rechazado sin romper nada")

    print("== 3. Lista de reproducción → paquete ==")
    n, _ = c.add_text("https://www.youtube.com/playlist?list=PLabcdefghijkl", "music")
    check(wait(lambda: len(c.packages) == 1), "la lista se convierte en paquete")
    pkg = next(iter(c.packages.values()))
    check(pkg.name == "Mi Lista" and len(pkg.items) == 4, f"paquete «{pkg.name}» con {len(pkg.items)} elementos (se descartó el enlace malo y el duplicado)")
    check(all(i.url.startswith("https://www.youtube.com/watch?v=") for i in pkg.items) and all(i.package is pkg for i in pkg.items), "los hijos son enlaces YouTube canónicos")
    check(c.out_dir_for(pkg.items[0]).name == "Mi Lista" and c.out_dir_for(pkg.items[0]).parent.name == "Musica", "se descargan en Musica/Mi Lista")

    print("== 4. Descarga con progreso real y global ==")
    solos = [j for j in c.jobs.values() if j.package is None]
    pct_seen, texts = [], []
    c2 = new_ctl(tmp / "b"); c2.add_text("https://youtu.be/dQw4w9WgXcQ https://vimeo.com/123", "music"); wait(lambda: all(j.meta_state == "ok" for j in c2.jobs.values()))
    check(c2.start(), "start()")
    while c2.running:
        p, t = c2.global_progress(); pct_seen.append(p); texts.append(t); time.sleep(0.02)
    check(all(p is not None for p in pct_seen) and pct_seen == sorted(pct_seen), f"global DETERMINADO y sin retroceder ({min(pct_seen):.0f}% → {max(pct_seen):.0f}%)")
    check(any("KiB/s" in t or "B/s" in t for t in texts) and any("ETA" in t for t in texts), "el texto global muestra velocidad y ETA reales")
    check(all(j.status == M.DONE and j.validated for j in c2.jobs.values()) and all(os.path.isfile(f) for j in c2.jobs.values() for f in j.files), "todo «Completado» y con archivos reales en disco")
    desc = c2.describe_batch(c2.last_batch)
    check(len(desc) == 1 and desc[0]["type"] == "complete" and desc[0]["size"] == sum(os.path.getsize(f) for f in desc[0]["files"]), f"resumen final con tamaño REAL ({desc[0]['size']} B) y carpeta {Path(desc[0]['folder']).name}")
    p, t = c2.global_progress(final=True); check(p == 100.0, "al terminar → 100 %")

    print("== 5. Paquete sin tamaños → progreso indeterminado ==")
    c.start(pkg.items[:2]); p, t = c.global_progress()
    check(p is None and "tamaño total desconocido" in t, f"indeterminado, sin inventar porcentaje → «{t}»"); idle(c)
    check(all(i.status == M.DONE for i in pkg.items[:2]), "los 2 elementos se descargaron")

    print("== 6. Pausar y reanudar ==")
    c3 = new_ctl(tmp / "c"); c3.add_text("https://youtu.be/SLOWSLOW001", "music"); wait(lambda: all(j.meta_state == "ok" for j in c3.jobs.values()))
    job3 = next(iter(c3.jobs.values())); c3.start(); wait(lambda: job3.progress > 10)
    check(c3.pause() == "", "pausa aceptada"); idle(c3)
    check(job3.status == M.PAUSED, "estado «Pausado»")
    part = [a for a in job3.artifacts if a.endswith(".part")]
    check(part and os.path.isfile(part[0]), "el .part se CONSERVA para reanudar")
    check(c3.resume(), "reanudar"); idle(c3)
    check(job3.status == M.DONE and os.path.isfile(job3.files[0]) and not os.path.exists(part[0]), "la reanudación termina y el .part desaparece")

    print("== 7. Cancelar y borrar el progreso (sin tocar nada ajeno) ==")
    c4 = new_ctl(tmp / "d"); c4.add_text("https://youtu.be/SLOWSLOW002", "music"); wait(lambda: all(j.meta_state == "ok" for j in c4.jobs.values()))
    job4 = next(iter(c4.jobs.values())); out4 = c4.out_dir_for(job4); out4.mkdir(parents=True, exist_ok=True)
    ajeno = out4 / "mi_cancion_vieja.m4a"; ajeno.write_bytes(b"A" * 100)
    fuera = tmp / "fuera.txt"; fuera.write_text("no tocar")
    c4.start(); wait(lambda: job4.progress > 10)
    job4.artifacts.append(str(fuera))  # aunque se registrara algo fuera de la carpeta, NO debe borrarse
    c4.cancel_and_discard(); idle(c4)
    check(not any(os.path.exists(a) for a in job4.artifacts) and not list(out4.glob("*.part")), "parciales eliminados")
    check(ajeno.exists() and ajeno.read_bytes() == b"A" * 100, "archivo ajeno de la misma carpeta INTACTO")
    check(fuera.exists(), "archivo fuera de la carpeta de la tarea INTACTO")
    check(job4.status == M.PENDING and job4.progress == 0, "la tarea queda lista para reintentar")

    print("== 8. Archivo que YA existía → nunca se borra ==")
    c5 = new_ctl(tmp / "e"); c5.add_text("https://youtu.be/PREEXIST001", "music"); wait(lambda: all(j.meta_state == "ok" for j in c5.jobs.values()))
    assert len(c5.jobs) == 1, "no se creó la tarea"; job5 = next(iter(c5.jobs.values())); out5 = c5.out_dir_for(job5); out5.mkdir(parents=True, exist_ok=True)
    viejo = out5 / "PREEXIST001.m4a"; viejo.write_bytes(b"V" * 300)
    c5.start(); idle(c5)
    check(str(viejo) in job5.preexisting and str(viejo) not in job5.artifacts, "se detecta como PREEXISTENTE")
    discard_partials(job5, out5); check(viejo.exists(), "discard_partials respeta lo preexistente")

    print("== 9. Directos ==")
    c6 = new_ctl(tmp / "f"); c6.add_text("https://www.youtube.com/live/LIVELIVE001", "video"); wait(lambda: all(j.meta_state == "ok" for j in c6.jobs.values()))
    job6 = next(iter(c6.jobs.values())); check(job6.live, "se reconoce que es un directo")
    c6.start(); wait(lambda: job6.loaded > 1000 and job6.rec_seconds > 0.1)
    check(c6.pause() != "", "un directo NO se puede pausar (mensaje explicativo)")
    p, t = c6.global_progress(); check(p is None and "🔴" in t, f"directo → indeterminado + tiempo grabado («{t}»)")
    c6.stop(); idle(c6)
    check(job6.status == M.DONE and job6.files and job6.files[0].endswith(".ts") and os.path.getsize(job6.files[0]) > 0, "al detener: .part → .ts finalizado y con contenido")
    check(not any(a.endswith(".part") and os.path.exists(a) for a in job6.artifacts), "no queda el .part")
    d6 = c6.describe_batch(c6.last_batch); check(d6 and d6[0]["type"] == "live", "se ofrece «¿conservar este directo?»")
    ajeno6 = Path(job6.files[0]).parent / "otro_video.mp4"; ajeno6.write_bytes(b"O" * 50)
    rec = job6.files[0]; check(c6.delete_recording(job6) >= 1 and not os.path.exists(rec) and ajeno6.exists(), "«No, eliminar» borra SOLO la grabación; lo demás intacto")
    c7 = new_ctl(tmp / "g"); c7.add_text("https://www.youtube.com/live/LIVEEND0001", "video"); wait(lambda: all(j.meta_state == "ok" for j in c7.jobs.values()))
    job7 = next(iter(c7.jobs.values())); c7.start(); idle(c7)
    check(job7.status == M.DONE and job7.validated and c7.describe_batch(c7.last_batch)[0]["type"] == "live", "directo que termina solo → validado y se ofrece conservarlo")

    print("== 10. Errores ==")
    c8 = new_ctl(tmp / "h"); c8.add_text("https://youtu.be/FAILFMT0001", "music"); wait(lambda: all(j.meta_state == "ok" for j in c8.jobs.values()))
    job8 = next(iter(c8.jobs.values())); c8.start(); idle(c8)
    check(job8.status == M.ERROR and "formato disponible" in job8.error, f"error de formato explicado: «{job8.error[:70]}»")
    d8 = c8.describe_batch(c8.last_batch); check(d8 and d8[0]["type"] == "error" and not any(x["type"] == "complete" for x in d8), "falla → diálogo de error, NUNCA «descarga completa»")
    c9 = new_ctl(tmp / "i"); n9, _ = c9.add_text("https://youtu.be/BADPROBE001", "music"); check(n9 == 1 and wait(lambda: len(c9.jobs) == 1 and all(j.meta_state == "fail" for j in c9.jobs.values())), "lectura fallida → «sin datos», la app sigue viva")
    check("JavaScript" in friendly_error("[youtube] WARNING: No supported JavaScript runtime could be found"), "aviso de runtime JS → explicación clara")

    print("== 11. Ajustes persistentes ==")
    c.settings["theme"] = "light"; c.settings["video_quality"] = "720"; c.save_settings()
    c10 = new_ctl(tmp); check(c10.settings["theme"] == "light" and c10.settings["video_quality"] == "720", "tema y calidad se recuerdan")
    Path(tmp / "cfg" / "settings.json").write_text('{"theme":"x","kind":5,"video_quality":"999"}'); c11 = new_ctl(tmp)
    check(c11.settings["theme"] == "dark" and c11.settings["kind"] == "music", "ajustes corruptos → valores por defecto")

    print("== 12. Carátula sin ffmpeg (mutagen) ==")
    info = {"extractor_key": "Youtube", "id": "dQw4w9WgXcQ", "thumbnail": "https://i.ytimg.com/vi_webp/x/maxresdefault.webp", "title": "Tema", "uploader": "Artista"}
    urls = covers.candidate_urls(info)
    check(len(urls) == 3 and all(u.endswith(".jpg") for u in urls), "URLs JPEG construidas desde el id (WebP descartado)")
    check(covers.candidate_urls({"extractor_key": "Generic", "thumbnail": "https://evil.com/a.jpg"}) == [], "hosts no permitidos descartados")
    saved = {}
    class FakeTags(dict):
        def add_tags(self): pass
    class FakeMP4:
        def __init__(self, path): self.tags = FakeTags(); self._d = self.tags
        def __setitem__(self, k, v): saved[k] = v
        def save(self): saved["saved"] = True
    mut = types.ModuleType("mutagen"); mp4 = types.ModuleType("mutagen.mp4")
    class FakeCover(bytes):
        FORMAT_JPEG = 13
        def __new__(cls, data, imageformat=13): return bytes.__new__(cls, data)
    mp4.MP4, mp4.MP4Cover = FakeMP4, FakeCover; sys.modules.update({"mutagen": mut, "mutagen.mp4": mp4})
    ok = covers.embed_cover(str(tmp / "t.m4a"), info, fetch=lambda u: b"J" * 2000)
    check(ok and saved.get("covr") and saved["\xa9nam"] == ["Tema"] and saved["\xa9ART"] == ["Artista"] and saved.get("saved"), "con mutagen: portada + título + artista + guardado")
    check(covers.embed_cover(str(tmp / "t.webm"), info, fetch=lambda u: b"J" * 2000) is False, "formatos no m4a → se omite sin error")

print("\nRESULTADO:", "TODO OK ✅" if not FAILS else f"{len(FAILS)} FALLO(S): {FAILS}")
sys.exit(1 if FAILS else 0)
