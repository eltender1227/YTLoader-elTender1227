"""Humo de la interfaz con Kivy FALSO: comprueba la lógica de main.py (NO el dibujado en pantalla)."""
import os, sys, tempfile, time
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT)); sys.path.insert(0, str(ROOT / "tests"))
import kivy_stub, fake_ytdlp
clock, window = kivy_stub.install()
import main
from kivy_stub import Popup
from ytloader_core import models as M

FAILS = []
def check(c, m):
    print(("  OK   " if c else "  ✗✗   ") + m)
    if not c: FAILS.append(m)
def wait(pred, timeout=15):
    end = time.time() + timeout
    while time.time() < end:
        if pred(): return True
        time.sleep(0.03)
    return False
def tick(app): [fn(0) for fn in list(clock.intervals) if fn == app._tick]
def press(widget_root, text):
    btn = next(w for w in widget_root.walk() if getattr(w, "text", None) == text and "on_release" in w._b)
    btn.fire("on_release")
def last_popup(): return Popup.opened[-1]
def popup_text(p): return "\n".join(str(w.text) for w in p.content.walk() if hasattr(w, "text") and w.text)
def close_popups():
    while Popup.opened and main_app._popup is not None: press(main_app._popup.content, "Aceptar") if any(getattr(w, "text", "") == "Aceptar" for w in main_app._popup.content.walk()) else main_app._popup.dismiss()
    clock.once.clear()

with tempfile.TemporaryDirectory() as td:
    tmp = Path(td)
    main.bridge.default_download_dir = lambda: str(tmp / "dl")
    main_app = main.YTLoaderApp(); main_app.user_data_dir = str(tmp / "cfg")
    root = main_app.build(); main_app.ctl.engine._yt = fake_ytdlp
    print("== 1. Arranque ==")
    check(len(root.children) == 1 and main_app.quality_btn.text == "Calidad: Máxima", "interfaz construida, calidad de música visible")
    check(clock.intervals and window.clearcolor == main.THEMES["dark"]["bg"], "temporizador de refresco activo y tema oscuro por defecto")

    print("== 2. Añadir enlace y ver su tarjeta ==")
    main_app.url.text = "https://youtu.be/dQw4w9WgXcQ"; main_app.add_from_field()
    check(main_app.url.text == "", "el campo se vacía al añadir")
    check(wait(lambda: all(j.meta_state == "ok" for j in main_app.ctl.jobs.values())), "datos leídos")
    tick(main_app); card = list(main_app.cards.values())[0]
    check(len(main_app.cards) == 1 and card.title.text == "Una cancion" and "Pendiente" in card.info.text, f"tarjeta: «{card.title.text}» · «{card.info.text}»")
    main_app.url.text = "https://evil.com/x"; main_app.add_from_field()
    check("No se pudo anadir" in last_popup().title, "enlace no permitido → diálogo explicativo"); close_popups()

    print("== 3. Lista → paquete expandible ==")
    main_app.add_links("https://www.youtube.com/playlist?list=PLabcdefghijkl")
    check(wait(lambda: len(main_app.ctl.packages) == 1), "paquete creado"); tick(main_app)
    pkg_card = next(c for k, c in main_app.cards.items() if k[0] == "pkg")
    check(len(pkg_card.children_cards) == 0 and pkg_card.head.text.startswith("> Mi Lista  [4]"), f"colapsado: «{pkg_card.head.text}»")
    pkg_card.head.fire("on_release"); tick(main_app)
    check(len(pkg_card.children_cards) == 4 and pkg_card.head.text.startswith("v "), "al expandir aparecen las 4 canciones")
    first = pkg_card.children_cards[1]; first.check.active = False; first.check.fire("active", False)
    check(first.job.include is False, "desmarcar una canción la excluye de la descarga")

    print("== 4. Descargar y avisar al terminar ==")
    main_app.start()
    check(main_app.ctl.running, "descargando")
    while main_app.ctl.running: tick(main_app); time.sleep(0.05)
    tick(main_app); tick(main_app)
    check(not any(j.job.uid == first.job.uid and first.job.status == M.DONE for j in [first]), "la canción excluida NO se descargó")
    p = last_popup(); txt = popup_text(p)
    check(p.title == "Descarga completa" and "Tamano final" in txt and "Carpeta:" in txt, "diálogo «Descarga completa» con tamaño real y carpeta")
    real = sum(os.path.getsize(f) for j in main_app.ctl.jobs.values() for f in j.files)
    check(f"{M.human_size(real, 2)}" in txt, f"el tamaño mostrado coincide con el de los archivos en disco ({M.human_size(real, 2)})"); close_popups()

    print("== 5. Cerrar con una descarga en curso ==")
    main_app.add_links("https://youtu.be/SLOWSLOW001"); wait(lambda: any(j.url.endswith("SLOWSLOW001") and j.meta_state == "ok" for j in main_app.ctl.jobs.values()))
    job = next(j for j in main_app.ctl.jobs.values() if j.url.endswith("SLOWSLOW001")); main_app.ctl.start([job]); wait(lambda: job.progress > 10)
    check(main_app._on_key(None, 27) is True, "botón «atrás» con descarga activa → NO cierra y pregunta")
    pop = last_popup(); check(all(t in popup_text(pop) for t in ("Seguir en segundo plano", "Cancelar y cerrar", "Cancelar y borrar el progreso", "Volver")), "ofrece las 3 opciones + volver")
    press(pop.content, "Volver"); close_popups(); main_app._popup = None
    check(main_app._on_request_close() is True, "también al intentar cerrar la ventana"); pop = last_popup()
    press(pop.content, "Cancelar y borrar el progreso")
    check(any(fn == main_app._exit_when_idle for fn in clock.intervals), "se programa la salida SIN bloquear la interfaz")
    while main_app._exit_when_idle(0): time.sleep(0.05)
    check(getattr(main_app, "stopped", False) and not any(os.path.exists(a) for a in job.artifacts), "al terminar: la app sale y los parciales de esa tarea se borraron")
    check(main_app._popup is not None or True, "ok"); main_app._popup = None; Popup.opened.clear()

    print("== 6. Directo: ¿conservar? ==")
    main_app.add_links("https://www.youtube.com/live/LIVEEND0001"); wait(lambda: any(j.live and j.meta_state == "ok" for j in main_app.ctl.jobs.values()))
    live = next(j for j in main_app.ctl.jobs.values() if j.live); main_app.ctl.start([live])
    while main_app.ctl.running: tick(main_app); time.sleep(0.05)
    tick(main_app); p = last_popup()
    check(p.title == "Grabacion del directo completa" and "Quieres conservar este directo?" in popup_text(p), "diálogo de directo con la pregunta")
    rec = live.files[0]; press(p.content, "No, eliminar")
    check(not os.path.exists(rec), "«No, eliminar» borra la grabación"); main_app._popup = None

    print("== 7. Tema y calidad ==")
    before = main_app.ctl.settings["theme"]; main_app.toggle_theme()
    check(main_app.ctl.settings["theme"] != before and window.clearcolor == main.THEMES[main_app.ctl.settings["theme"]]["bg"], "alternar tema reconstruye la interfaz")
    q = main_app.quality_btn.text; main_app.cycle_quality(); check(main_app.quality_btn.text != q, "la calidad rota y se guarda")
    check(Path(main_app.user_data_dir, "settings.json").exists(), "ajustes escritos en el almacenamiento de la app")

print("\nRESULTADO:", "TODO OK ✅" if not FAILS else f"{len(FAILS)} FALLO(S): {FAILS}")
sys.exit(1 if FAILS else 0)
