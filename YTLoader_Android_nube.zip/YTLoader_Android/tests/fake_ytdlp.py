"""Módulo yt_dlp FALSO (misma interfaz que usa el motor) para probar sin red ni Android."""
import os, time
from pathlib import Path

class _Utils:
    class DownloadCancelled(Exception): pass
utils = _Utils()
class DownloadError(Exception): pass

def _vid(url): return url.split("v=")[-1].split("&")[0].split("/")[-1][:20]

class YoutubeDL:
    def __init__(self, opts): self.opts = opts
    def __enter__(self): return self
    def __exit__(self, *a): return False
    def prepare_filename(self, info): return info.get("_fn", "")

    def extract_info(self, url, download=True):
        if not download:
            if "BADPROBE" in url: raise DownloadError("ERROR: Unsupported URL")
            if "PLAYLIST" in url or "playlist" in url:
                ents = [{"url": f"https://www.youtube.com/watch?v=aaaaaaaaaa{i}", "title": f"Cancion {i}", "duration": 100 + i} for i in range(4)]
                ents.append({"url": "https://evil.com/x", "title": "malo"})                      # debe descartarse
                ents.append({"url": "https://www.youtube.com/watch?v=aaaaaaaaaa0", "title": "dup"})  # duplicado
                return {"_type": "playlist", "title": "Mi Lista", "entries": ents}
            if "LIVE" in url: return {"title": "Directo", "is_live": True, "formats": []}
            return {"title": "Una cancion", "duration": 200, "formats": [
                {"vcodec": "none", "acodec": "mp4a", "filesize": 5_000_000},
                {"vcodec": "avc1", "acodec": "mp4a", "filesize": 20_000_000, "height": 720},
                {"vcodec": "avc1", "acodec": "mp4a", "filesize": 8_000_000, "height": 360}]}
        return self._download(url)

    def _download(self, url):
        o = self.opts; hook = o["progress_hooks"][0]; logger = o["logger"]
        out = Path(o["outtmpl"]).parent; out.mkdir(parents=True, exist_ok=True)
        base = _vid(url); ext = "mp4" if "FMT_VIDEO" in url else "m4a"
        final = str(out / f"{base}.{ext}"); part = final + ".part"
        if "FAILFMT" in url:
            logger.error("ERROR: [youtube] X: Requested format is not available. Use --list-formats for a list of available formats")
            raise DownloadError("ERROR: [youtube] X: Requested format is not available")
        if "PREEXIST" in url and os.path.exists(final):
            hook({"status": "finished", "filename": final, "downloaded_bytes": os.path.getsize(final)})
            return {"requested_downloads": [{"filepath": final}], "id": base}
        if "LIVE" in url:
            t0 = time.time(); n = 0
            while True:
                n += 1; open(part, "ab").write(b"x" * 500)
                hook({"status": "downloading", "tmpfilename": part, "filename": final, "downloaded_bytes": 500 * n, "speed": 1000.0, "elapsed": time.time() - t0})
                time.sleep(0.05)
                if "LIVEEND" in url and time.time() - t0 > 0.5:
                    os.replace(part, final); hook({"status": "finished", "filename": final, "downloaded_bytes": 500 * n})
                    return {"requested_downloads": [{"filepath": final}], "id": base}
        total = 5_000_000; resumed = os.path.exists(part)
        steps = 2 if resumed else 6
        slow = "SLOW" in url and not resumed
        for i in range(steps + 1):
            got = int(total * i / steps)
            open(part, "wb").write(b"x" * max(got // 1000, 1))
            hook({"status": "downloading", "tmpfilename": part, "filename": final, "downloaded_bytes": got, "total_bytes": total, "speed": 360_000.0, "eta": steps - i})
            time.sleep(0.4 if slow else 0.03)
        os.replace(part, final)
        hook({"status": "finished", "filename": final, "total_bytes": total})
        return {"requested_downloads": [{"filepath": final}], "id": base, "title": base, "extractor_key": "Youtube"}
