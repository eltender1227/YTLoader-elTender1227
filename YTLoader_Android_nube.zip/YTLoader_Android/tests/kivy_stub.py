"""Kivy FALSO: permite ejecutar la lógica de main.py sin pantalla (NO prueba el dibujado)."""
import sys, types

class _Ctx:
    def __enter__(self): return self
    def __exit__(self, *a): return False
class _Canvas:
    before = _Ctx()
    def __init__(self): pass
class W:
    def __init__(self, **kw):
        self.children = []; self._b = {}; self.canvas = _Canvas()
        self.width, self.height, self.size, self.pos, self.texture_size, self.minimum_height = 100, 20, (100, 20), (0, 0), (10, 10), 0
        self.text = ""; self.state = "normal"; self.value = 0; self.active = False
        for k, v in kw.items(): setattr(self, k, v)
    def add_widget(self, w): self.children.append(w)
    def remove_widget(self, w): self.children.remove(w)
    def clear_widgets(self): self.children.clear()
    def bind(self, **kw):
        for k, v in kw.items(): self._b.setdefault(k, []).append(v)
    def setter(self, name): return lambda *a: setattr(self, name, a[-1])
    def fire(self, ev, *a):
        for cb in list(self._b.get(ev, [])): cb(self, *a)
    def walk(self):
        yield self
        for c in self.children:
            if hasattr(c, "walk"): yield from c.walk()
            else: yield c
class Popup(W):
    opened = []
    def open(self): Popup.opened.append(self)
    def dismiss(self): self.fire("on_dismiss")
class _Clock:
    def __init__(self): self.intervals = []; self.once = []
    def schedule_interval(self, fn, dt): self.intervals.append(fn); return fn
    def schedule_once(self, fn, dt=0): self.once.append(fn); return fn
class _Window(W):
    clearcolor = None
class App:
    user_data_dir = "/tmp"
    def stop(self): self.stopped = True
    def run(self): pass

def install():
    mods = {n: types.ModuleType(n) for n in (
        "kivy", "kivy.app", "kivy.clock", "kivy.core", "kivy.core.clipboard", "kivy.core.window", "kivy.graphics", "kivy.metrics",
        "kivy.uix", "kivy.uix.boxlayout", "kivy.uix.button", "kivy.uix.checkbox", "kivy.uix.label", "kivy.uix.popup",
        "kivy.uix.progressbar", "kivy.uix.scrollview", "kivy.uix.textinput", "kivy.uix.togglebutton")}
    mods["kivy.app"].App = App
    clock = _Clock(); mods["kivy.clock"].Clock = clock
    mods["kivy.core.clipboard"].Clipboard = types.SimpleNamespace(paste=lambda: "https://youtu.be/dQw4w9WgXcQ")
    window = _Window(); mods["kivy.core.window"].Window = window
    mods["kivy.graphics"].Color = lambda *a: None
    mods["kivy.graphics"].RoundedRectangle = lambda **kw: types.SimpleNamespace(**kw)
    mods["kivy.metrics"].dp = lambda v: v
    for mod, cls in (("boxlayout", "BoxLayout"), ("button", "Button"), ("checkbox", "CheckBox"), ("label", "Label"),
                     ("popup", "Popup"), ("progressbar", "ProgressBar"), ("scrollview", "ScrollView"),
                     ("textinput", "TextInput"), ("togglebutton", "ToggleButton")):
        setattr(mods[f"kivy.uix.{mod}"], cls, Popup if cls == "Popup" else W)
    sys.modules.update(mods)
    return clock, window
