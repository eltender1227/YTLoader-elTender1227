[app]
title = YTLoader
package.name = ytloader
package.domain = org.ytloader
source.dir = .
source.include_exts = py,png,jpg,json,xml
source.exclude_dirs = tests, bin, .buildozer
version = 0.1.0

# yt-dlp y mutagen son Python puro. NO hay ffmpeg: música = m4a con carátula (mutagen); video = formato ya mezclado.
# Opcional: añade «pillow» para recortar la carátula a cuadrado (necesita compilarse y alarga la construcción).
requirements = python3,kivy==2.3.0,pyjnius,android,certifi,mutagen,yt-dlp

orientation = portrait
fullscreen = 0
icon.filename = %(source.dir)s/icon.png

android.permissions = INTERNET,ACCESS_NETWORK_STATE,POST_NOTIFICATIONS
android.api = 34
android.minapi = 24
android.archs = arm64-v8a
android.accept_sdk_license = True
android.manifest.intent_filters = intent_filters.xml

[buildozer]
log_level = 2
warn_on_root = 1
