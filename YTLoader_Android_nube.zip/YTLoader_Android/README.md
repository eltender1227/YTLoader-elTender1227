# YTLoader para Android (Kivy)

## Contenido
```
main.py               Interfaz Kivy (solo vista)
android_bridge.py     Lo específico de Android: carpeta, permisos, «Compartir», MediaStore, segundo plano
ytloader_core/        Lógica SIN interfaz: motor yt-dlp, cola, pausa/cancelar, progreso, validación de enlaces
buildozer.spec        Empaquetado del APK            intent_filters.xml  «Compartir → YTLoader»
icon.png              Icono                          tests/              Pruebas (no van en el APK)
```

## Compilar el APK (Linux o WSL2; en Windows puro no funciona)
```
sudo apt install -y git zip unzip openjdk-17-jdk python3-pip autoconf libtool pkg-config zlib1g-dev \
     libncurses5-dev libffi-dev libssl-dev
pip install --user buildozer cython
buildozer android debug          # la 1.ª vez descarga SDK/NDK (~ 20-40 min)
adb install -r bin/ytloader-0.1.0-arm64-v8a-debug.apk
```

## Probar la lógica en tu ordenador (sin Android ni Kivy)
```
python tests/test_core.py        # motor, cola, pausa, cancelar, directos, errores, ajustes (yt-dlp simulado)
python tests/test_ui_smoke.py    # lógica de main.py con Kivy simulado
```
Para probar con yt-dlp REAL en el PC: `pip install yt-dlp mutagen kivy` y `python main.py`.

## Cómo se comporta en Android
- Descarga a la carpeta propia de la app (no pide permisos) y, al terminar, COPIA a Música/YTLoader o
  Películas/YTLoader (Android 10+). El original se conserva en la carpeta de la app.
- Sin ffmpeg: música = m4a tal cual con carátula y etiquetas (mutagen); video = formato ya mezclado
  (en YouTube suele ser 360p-720p). Con ffmpeg disponible (variable YTLOADER_FFMPEG) se usa el flujo de escritorio.
- Pausar = detener conservando el .part; Reanudar continúa. Un directo no se pausa: «Detener» lo finaliza (.ts).
- «Compartir» desde otra app envía el enlace a YTLoader.

## Limitaciones conocidas (léelas)
1. **YouTube**: yt-dlp necesita un runtime de JavaScript (deno/node) que Android NO incluye. Algunos videos
   o formatos pueden fallar. Otras plataformas (TikTok, SoundCloud, Vimeo, X, Reddit, Twitch, Bilibili,
   Dailymotion…) no lo necesitan. Si YouTube es lo principal, la vía fiable es Termux con nodejs.
2. **Segundo plano**: sin un servicio en primer plano Android puede cerrar la app con la pantalla apagada.
   «Seguir en segundo plano» solo la envía al fondo. Un servicio (p4a `services`) es la mejora pendiente.
3. **Google Play** suele rechazar descargadores de YouTube: distribuye el APK por instalación directa.
4. No se probó en un dispositivo: `android_bridge.py` y el dibujado de Kivy están SIN verificar.

## Compilar el APK EN LA NUBE (sin instalar nada)
1. Crea una cuenta en github.com y un repositorio nuevo (privado vale).
2. Sube TODO el contenido de esta carpeta (incluida `.github/`; en «Add file → Upload files» arrastra la carpeta).
3. Pestaña **Actions → Compilar APK → Run workflow**. Tarda ~30-60 min la primera vez.
4. Al terminar, entra en la ejecución y descarga **YTLoader-apk** (un zip con el `.apk`).
5. Pásalo al móvil, ábrelo y permite «instalar apps desconocidas».
⚠ Este flujo no se pudo probar desde aquí. Si falla, copia el error del registro y se corrige.
