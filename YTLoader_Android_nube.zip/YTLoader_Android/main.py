# -*- coding: utf-8 -*-
"""
YTLoader para Android (Kivy). Solo interfaz: toda la lógica está en ytloader_core (probada sin Kivy).
Sin emojis a propósito: la fuente por defecto de Kivy no los dibuja (saldrían cuadrados).
"""
import os
import shutil
import threading

from kivy.app import App
from kivy.clock import Clock
from kivy.core.clipboard import Clipboard
from kivy.core.window import Window
from kivy.graphics import Color, RoundedRectangle
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.checkbox import CheckBox
from kivy.uix.label import Label
from kivy.uix.popup import Popup
from kivy.uix.progressbar import ProgressBar
from kivy.uix.scrollview import ScrollView
from kivy.uix.textinput import TextInput
from kivy.uix.togglebutton import ToggleButton

import android_bridge as bridge
from ytloader_core import models as M
from ytloader_core.controller import Controller
from ytloader_core.engine import DownloadEngine
from ytloader_core.options import MUSIC_QUALITIES, VIDEO_QUALITIES

UI_STATUS = {M.PENDING: "Pendiente", M.RUNNING: "Descargando", M.DONE: "Completado", M.ERROR: "Error",
             M.PAUSED: "Pausado", M.CANCELLED: "Cancelado"}
THEMES = {
    "dark": dict(bg=(.07, .07, .08, 1), card=(.14, .14, .16, 1), fg=(.93, .93, .94, 1), muted=(.62, .64, .68, 1),
                 accent=(.17, .83, .65, 1), accent_fg=(.04, .07, .12, 1), btn=(.22, .22, .25, 1),
                 ok=(.31, .76, .48, 1), error=(.96, .44, .40, 1), field=(.18, .18, .20, 1)),
    "light": dict(bg=(.94, .94, .95, 1), card=(1, 1, 1, 1), fg=(.10, .10, .11, 1), muted=(.33, .35, .38, 1),
                  accent=(.04, .48, .37, 1), accent_fg=(1, 1, 1, 1), btn=(.86, .86, .88, 1),
                  ok=(.10, .50, .22, 1), error=(.78, .16, .16, 1), field=(1, 1, 1, 1)),
}


def find_ffmpeg():
    """ffmpeg solo si existe (en Android normalmente NO): el motor se adapta solo."""
    return os.environ.get("YTLOADER_FFMPEG") or shutil.which("ffmpeg")


class Line(Label):
    """Etiqueta de UNA línea que se acorta con «…» si no cabe."""

    def __init__(self, height=22, **kw):
        kw.setdefault("size_hint_y", None)
        kw.setdefault("halign", "left")
        kw.setdefault("valign", "middle")
        kw.setdefault("shorten", True)
        kw.setdefault("shorten_from", "right")
        super().__init__(height=dp(height), **kw)
        self.bind(size=lambda *_: setattr(self, "text_size", (self.width, self.height)))


class Wrap(Label):
    """Etiqueta de varias líneas con altura automática (para diálogos)."""

    def __init__(self, **kw):
        kw.setdefault("size_hint_y", None)
        kw.setdefault("halign", "left")
        kw.setdefault("valign", "top")
        super().__init__(**kw)
        self.bind(width=lambda *_: setattr(self, "text_size", (self.width, None)),
                  texture_size=lambda *_: setattr(self, "height", self.texture_size[1] + dp(4)))


class Card(BoxLayout):
    def __init__(self, color, **kw):
        kw.setdefault("orientation", "vertical")
        kw.setdefault("size_hint_y", None)
        kw.setdefault("padding", dp(10))
        kw.setdefault("spacing", dp(4))
        super().__init__(**kw)
        self.bind(minimum_height=self.setter("height"))
        with self.canvas.before:
            Color(*color)
            self._rect = RoundedRectangle(pos=self.pos, size=self.size, radius=[dp(10)])
        self.bind(pos=self._sync, size=self._sync)

    def _sync(self, *_):
        self._rect.pos, self._rect.size = self.pos, self.size


class JobCard(Card):
    def __init__(self, app, job, child=False):
        super().__init__(app.t["card"])
        self.app, self.job = app, job
        row = BoxLayout(size_hint_y=None, height=dp(30), spacing=dp(6))
        if child:
            self.check = CheckBox(active=job.include, size_hint_x=None, width=dp(34))
            self.check.bind(active=lambda _w, v: setattr(job, "include", v))
            row.add_widget(self.check)
        self.title = Line(color=app.t["fg"], font_size=dp(15), bold=True)
        row.add_widget(self.title)
        remove = Button(text="X", size_hint_x=None, width=dp(34), background_normal="", background_color=app.t["btn"],
                        color=app.t["fg"])
        remove.bind(on_release=lambda *_: app.ctl.remove(job))
        row.add_widget(remove)
        self.add_widget(row)
        self.info = Line(color=app.t["muted"], font_size=dp(12))
        self.bar = ProgressBar(max=100, size_hint_y=None, height=dp(8))
        self.add_widget(self.info)
        self.add_widget(self.bar)
        self.update()

    def update(self):
        j, t = self.job, self.app.t
        name = j.title if j.meta_state == "ok" else ("Leyendo datos…" if j.meta_state == "loading" else "Sin datos: " + j.url)
        self.title.text = name or j.url
        if j.status == M.RUNNING and j.live:
            info = f"Grabando {M.hms(j.rec_seconds)} · {M.human_size(j.loaded)}"
        elif j.status == M.RUNNING:
            info = f"{j.progress:.0f}% · {M.human_size(M.job_loaded_bytes(j))} / {M.human_size(M.job_total_bytes(j))}"
            info += f" · {M.human_speed(j.speed)}" + (f" · ETA {M.human_eta(j.eta)}" if j.eta else "")
        elif j.status == M.ERROR:
            info = "Error: " + (j.error or "desconocido")
        else:
            info = UI_STATUS[j.status] + (f" · {M.human_size(M.job_total_bytes(j))}" if M.job_total_bytes(j) else "")
            if j.status == M.DONE and j.cover_embedded:
                info += " · con caratula"
        self.info.text = info
        self.info.color = t["error"] if j.status == M.ERROR else (t["ok"] if j.status == M.DONE else t["muted"])
        self.bar.value = 100 if j.status == M.DONE else j.progress


class PackageCard(Card):
    def __init__(self, app, package):
        super().__init__(app.t["card"])
        self.app, self.package = app, package
        self.head = Button(text="", size_hint_y=None, height=dp(40), background_normal="", halign="left",
                           background_color=app.t["btn"], color=app.t["fg"])
        self.head.bind(on_release=self._toggle)
        self.add_widget(self.head)
        self.info = Line(color=app.t["muted"], font_size=dp(12))
        self.add_widget(self.info)
        self.children_cards = []
        self.update()

    def _toggle(self, *_):
        self.package.expanded = not self.package.expanded
        self.update(force=True)

    def update(self, force=False):
        p = self.package
        done = sum(1 for j in p.items if j.status == M.DONE)
        self.head.text = ("v " if p.expanded else "> ") + f"{p.name}  [{len(p.items)}]"
        self.info.text = f"{done}/{len(p.items)} completados · se guarda en Musica o Videos / {p.name}"
        want = [j.uid for j in p.items] if p.expanded else []
        if force or want != [c.job.uid for c in self.children_cards]:
            for card in self.children_cards:
                self.remove_widget(card)
            self.children_cards = []
            for job in (p.items if p.expanded else []):
                card = JobCard(self.app, job, child=True)
                self.children_cards.append(card)
                self.add_widget(card)
        for card in self.children_cards:
            card.update()


class YTLoaderApp(App):
    title = "YTLoader"

    # ------------------------------------------------------------ arranque
    def build(self):
        engine = DownloadEngine(ffmpeg=find_ffmpeg())
        self.ctl = Controller(engine, bridge.default_download_dir(), os.path.join(self.user_data_dir, "settings.json"))
        self.t = THEMES[self.ctl.settings["theme"]]
        self.cards, self._order, self._seen, self._dialogs, self._popup = {}, None, -1, [], None
        self.container = BoxLayout()
        self._build_ui()
        Window.bind(on_keyboard=self._on_key, on_request_close=self._on_request_close)
        Clock.schedule_interval(self._tick, 0.4)
        bridge.request_permissions()
        bridge.bind_new_intent(lambda text: Clock.schedule_once(lambda _dt: self.add_links(text), 0))
        return self.container

    def on_start(self):
        shared = bridge.get_shared_text()
        if shared:
            self.add_links(shared)

    def on_pause(self):
        return True  # imprescindible en Android: sin esto la app se destruye al pasar a segundo plano

    def on_resume(self):
        self._seen = -1

    # ------------------------------------------------------------ interfaz
    def _button(self, text, callback, primary=False, **kw):
        t = self.t
        b = Button(text=text, background_normal="", background_color=t["accent"] if primary else t["btn"],
                   color=t["accent_fg"] if primary else t["fg"], **kw)
        b.bind(on_release=lambda *_: callback())
        return b

    def _build_ui(self):
        t = self.t
        Window.clearcolor = t["bg"]
        root = BoxLayout(orientation="vertical", padding=dp(10), spacing=dp(8))
        root.add_widget(Line(text="YTLoader", font_size=dp(22), bold=True, color=t["accent"], height=34))

        row = BoxLayout(size_hint_y=None, height=dp(46), spacing=dp(6))
        self.url = TextInput(multiline=False, hint_text="Pega un enlace (YouTube, TikTok, SoundCloud...)",
                             background_color=t["field"], foreground_color=t["fg"], hint_text_color=t["muted"],
                             cursor_color=t["accent"], write_tab=False)
        self.url.bind(on_text_validate=lambda *_: self.add_from_field())
        row.add_widget(self.url)
        row.add_widget(self._button("Pegar", self.paste, size_hint_x=None, width=dp(72)))
        row.add_widget(self._button("Anadir", self.add_from_field, primary=True, size_hint_x=None, width=dp(78)))
        root.add_widget(row)

        mode = BoxLayout(size_hint_y=None, height=dp(42), spacing=dp(6))
        self.music_btn = ToggleButton(text="Musica", group="kind", state="down" if self.ctl.settings["kind"] == "music" else "normal",
                                      background_normal="", background_down="", allow_no_selection=False)
        self.video_btn = ToggleButton(text="Video", group="kind", state="down" if self.ctl.settings["kind"] == "video" else "normal",
                                      background_normal="", background_down="", allow_no_selection=False)
        for btn, kind in ((self.music_btn, "music"), (self.video_btn, "video")):
            btn.bind(on_release=lambda _w, k=kind: self.set_kind(k))
            mode.add_widget(btn)
        self.quality_btn = self._button("", self.cycle_quality)
        mode.add_widget(self.quality_btn)
        root.add_widget(mode)
        self._paint_mode()

        self.global_bar = ProgressBar(max=100, size_hint_y=None, height=dp(10))
        self.global_text = Line(text="", color=t["muted"], font_size=dp(12))
        root.add_widget(self.global_bar)
        root.add_widget(self.global_text)

        scroll = ScrollView()
        self.list_box = BoxLayout(orientation="vertical", size_hint_y=None, spacing=dp(8))
        self.list_box.bind(minimum_height=self.list_box.setter("height"))
        scroll.add_widget(self.list_box)
        root.add_widget(scroll)

        bar = BoxLayout(size_hint_y=None, height=dp(48), spacing=dp(6))
        bar.add_widget(self._button("Iniciar", self.start, primary=True))
        self.pause_btn = self._button("Pausar", self.pause_or_resume)
        bar.add_widget(self.pause_btn)
        bar.add_widget(self._button("Detener", self.ctl.stop))
        bar.add_widget(self._button("Mas", self.show_menu, size_hint_x=None, width=dp(70)))
        root.add_widget(bar)
        self.container.clear_widgets()
        self.container.add_widget(root)
        self.cards.clear()
        self._order, self._seen = None, -1

    def _paint_mode(self):
        t = self.t
        for btn in (self.music_btn, self.video_btn):
            btn.background_color = t["accent"] if btn.state == "down" else t["btn"]
            btn.color = t["accent_fg"] if btn.state == "down" else t["fg"]
        kind = self.ctl.settings["kind"]
        table = MUSIC_QUALITIES if kind == "music" else VIDEO_QUALITIES
        self.quality_btn.text = "Calidad: " + table[self.ctl.quality_for(kind)]

    # ------------------------------------------------------------ acciones
    def paste(self):
        self.url.text = (Clipboard.paste() or "").strip()
        self.add_from_field()

    def add_from_field(self):
        self.add_links(self.url.text)

    def add_links(self, text):
        added, errors = self.ctl.add_text(text, self.ctl.settings["kind"])
        if added:
            self.url.text = ""
        if errors and not added:
            self.dialog("No se pudo anadir", errors[:4], [("Aceptar", None)])
        self._seen = -1

    def set_kind(self, kind):
        self.ctl.settings["kind"] = kind
        self.ctl.save_settings()
        self._paint_mode()

    def cycle_quality(self):
        kind = self.ctl.settings["kind"]
        key = "music_quality" if kind == "music" else "video_quality"
        keys = list(MUSIC_QUALITIES if kind == "music" else VIDEO_QUALITIES)
        self.ctl.settings[key] = keys[(keys.index(self.ctl.settings[key]) + 1) % len(keys)]
        self.ctl.save_settings()
        self._paint_mode()

    def start(self):
        if not self.ctl.start():
            self.dialog("Nada que descargar", ["Anade enlaces o pulsa Reanudar si hay descargas pausadas."], [("Aceptar", None)])

    def pause_or_resume(self):
        if self.ctl.running:
            reason = self.ctl.pause()
            if reason:
                self.dialog("No se puede pausar", [reason], [("Aceptar", None)])
        else:
            self.ctl.resume()

    def toggle_theme(self):
        self.ctl.settings["theme"] = "light" if self.ctl.settings["theme"] == "dark" else "dark"
        self.ctl.save_settings()
        self.t = THEMES[self.ctl.settings["theme"]]
        self._build_ui()

    def show_menu(self):
        def after(fn):
            return lambda: fn()
        self.dialog("Opciones", [], [
            ("Cambiar tema claro / oscuro", self.toggle_theme),
            ("Limpiar completados", self.ctl.clear_done),
            ("Cancelar y borrar parciales", lambda: self.confirm_discard()),
            ("Ver registro", self.show_log),
            ("Cerrar", None)], vertical=True)

    def confirm_discard(self):
        self.dialog("Cancelar y borrar el progreso", ["Se cancelaran las descargas y se borraran SOLO sus archivos parciales.",
                                                      "No se tocan archivos completos ni ajenos."],
                    [("Continuar", self.ctl.cancel_and_discard), ("Volver", None)])

    def show_log(self):
        self.dialog("Registro", ["\n".join(list(self.ctl.log_lines)[-60:]) or "(vacio)"], [("Cerrar", None)])

    # ------------------------------------------------------------ cerrar / segundo plano
    def _on_key(self, _window, key, *_args):
        if key == 27:  # botón «atrás» de Android
            return self._ask_close()
        return False

    def _on_request_close(self, *_args):
        return self._ask_close()

    def _ask_close(self):
        if not self.ctl.running:
            return False  # nada en curso: se cierra normal
        self.dialog("Hay descargas en curso", [self.global_text.text, "", "Que quieres hacer?"], [
            ("Seguir en segundo plano", lambda: (bridge.move_to_background())),
            ("Cancelar y cerrar", lambda: self._cancel_and_exit(False)),
            ("Cancelar y borrar el progreso", lambda: self._cancel_and_exit(True)),
            ("Volver", None)], vertical=True)
        return True  # bloquea el cierre hasta que el usuario elija

    def _cancel_and_exit(self, discard):
        (self.ctl.cancel_and_discard if discard else self.ctl.stop)()
        self._waiting = 0
        Clock.schedule_interval(self._exit_when_idle, 0.2)

    def _exit_when_idle(self, _dt):
        self._waiting += 1
        if self.ctl.running and self._waiting < 50:  # hasta ~10 s sin bloquear la interfaz
            return True
        self.stop()
        return False

    # ------------------------------------------------------------ diálogos (en cola, de uno en uno)
    def dialog(self, title, lines, buttons, vertical=False, default=None):
        self._dialogs.append((title, lines, buttons, vertical, default))
        self._next_dialog()

    def _next_dialog(self):
        if self._popup is not None or not self._dialogs:
            return
        title, lines, buttons, vertical, default = self._dialogs.pop(0)
        t = self.t
        body = BoxLayout(orientation="vertical", spacing=dp(8), padding=dp(10))
        scroll = ScrollView()
        inner = BoxLayout(orientation="vertical", size_hint_y=None, spacing=dp(4))
        inner.bind(minimum_height=inner.setter("height"))
        for line in lines:
            inner.add_widget(Wrap(text=line, color=t["fg"], font_size=dp(14)))
        scroll.add_widget(inner)
        body.add_widget(scroll)
        row = BoxLayout(orientation="vertical" if vertical else "horizontal", size_hint_y=None, spacing=dp(6),
                        height=dp(46 * len(buttons) if vertical else 46))
        state = {"chosen": False}
        popup = Popup(title=title, content=body, size_hint=(0.92, 0.7 if (lines or vertical) else 0.4), auto_dismiss=False)

        def close(callback):
            state["chosen"] = True
            popup.dismiss()
            if callback:
                callback()

        for label, callback in buttons:
            row.add_widget(self._button(label, lambda cb=callback: close(cb)))
        body.add_widget(row)

        def dismissed(*_):
            self._popup = None
            if not state["chosen"] and default:
                default()  # cerrar sin elegir = opción segura (p. ej. conservar el directo)
            Clock.schedule_once(lambda _dt: self._next_dialog(), 0.1)

        popup.bind(on_dismiss=dismissed)
        self._popup = popup
        popup.open()

    # ------------------------------------------------------------ actualización periódica
    def _tick(self, _dt):
        ctl = self.ctl
        pct, text = ctl.global_progress()
        self.global_text.text = text
        self.global_bar.value = pct if pct is not None else 0
        self.pause_btn.text = "Reanudar" if (not ctl.running and any(j.status == M.PAUSED for j in ctl.jobs.values())) else "Pausar"
        if ctl.version != self._seen:
            self._seen = ctl.version
            self._refresh_list()
        while ctl.notices:
            self._handle_notice(ctl.notices.popleft())

    def _refresh_list(self):
        ctl = self.ctl
        order = [("pkg", p.pid) for p in ctl.packages.values()] + \
                [("job", j.uid) for j in ctl.jobs.values() if j.package is None]
        if order != self._order:
            self.list_box.clear_widgets()
            for kind, ident in order:
                card = self.cards.get((kind, ident))
                if card is None:
                    card = PackageCard(self, ctl.packages[ident]) if kind == "pkg" else JobCard(self, ctl.jobs[ident])
                    self.cards[(kind, ident)] = card
                self.list_box.add_widget(card)
            for key in [k for k in self.cards if k not in order]:
                del self.cards[key]
            self._order = order
        for card in self.cards.values():
            card.update()

    def _handle_notice(self, notice):
        if notice.get("type") != "batch":
            return
        threading.Thread(target=self._publish, args=(notice.get("finished", []),), daemon=True).start()
        for item in self.ctl.describe_batch(notice):
            if item["type"] == "complete":
                names = [os.path.basename(f) for f in item["files"]]
                lines = [f"Archivos ({len(names)}):"] + ["  " + n for n in names[:6]]
                lines += ([f"  ... y {len(names) - 6} mas"] if len(names) > 6 else [])
                lines += ["", f"Tamano final: {M.human_size(item['size'], 2)}", f"Carpeta: {item['folder']}"]
                if item["failed"]:
                    lines.append(f"{item['failed']} elemento(s) fallaron.")
                self.dialog("Descarga completa", lines, [("Aceptar", None)])
            elif item["type"] == "live":
                job = item["job"]
                lines = [f"Archivo: {os.path.basename(item['files'][0])}", f"Tamano final: {M.human_size(item['size'], 2)}",
                         "", "Quieres conservar este directo?"]
                self.dialog("Grabacion del directo completa", lines,
                            [("Si, conservar", None), ("No, eliminar", lambda j=job: self.ctl.delete_recording(j))],
                            default=None)  # cerrar sin elegir = conservar
            elif item["type"] == "error":
                lines = ["No se pudo completar la descarga:", ""] + [f"- {(j.title or j.url)[:50]}: {j.error}" for j in item["jobs"][:4]]
                self.dialog("Error en la descarga", lines, [("Aceptar", None)])

    def _publish(self, jobs):
        for job in jobs:
            for path in job.files:
                bridge.publish_to_media_store(path, job.kind)


if __name__ == "__main__":
    YTLoaderApp().run()
